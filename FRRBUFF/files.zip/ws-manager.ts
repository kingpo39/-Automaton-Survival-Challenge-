/**
 * platform/ws-manager.ts
 *
 * Resilient WebSocket manager for the Conway survival agent.
 *
 * Survival challenge failure modes (specific to this stack):
 *   1. Windows NAT timeout: home routers reset idle connections at 60-90s
 *      → Fix: ping every 25s, well below the NAT floor
 *   2. Server-side relay timeout: social relay drops idle clients
 *      → Fix: same ping; server resets its idle timer on each ping
 *   3. Network blip (brief disconnect): ISP drops for 2-5s
 *      → Fix: fast reconnect (0.5s first attempt), SQLite queue preserves messages
 *   4. Extended outage: OmniRoute restart, relay server restart, internet down
 *      → Fix: exponential backoff with cap; switch to HTTP polling when WS gives up
 *   5. Critical/dead tier: agent must conserve CPU and reduce network activity
 *      → Fix: survival-aware reconnect limits; stop WS in dead tier, rely on HTTP poll only
 *   6. Windows sleep/hibernate: OS kills all sockets on suspend
 *      → Fix: OS wake event triggers immediate reconnect (register powersaving listener)
 *
 * ARCHITECTURE:
 *   This class manages ONE WebSocket connection (to the social relay).
 *   It is NOT used for Ollama or OmniRoute inference (those are HTTP).
 *   It emits all events to the bus; other subsystems subscribe, not poll.
 */

import WebSocket from 'ws'
import { createLogger } from '../observability/logger'
import { bus } from '../core/event-bus/index'
import type { SurvivalTier } from '../core/event-bus/index'
import type { AutomatonDatabase } from '../state/database'

const log = createLogger('platform:ws-manager')

// ── Config ───────────────────────────────────────────────────────────────────

export interface WSConfig {
  url: string                   // wss://social.relay.example.com
  pingIntervalMs:  number       // default 25_000 (below NAT floor of 60-90s)
  pongTimeoutMs:   number       // default 10_000 (how long to wait for pong)
  maxRetriesByTier: Record<SurvivalTier, number>
  baseBackoffMs:   number       // default 500
  maxBackoffMs:    number       // default 60_000
  jitterFactor:    number       // 0-1, default 0.3
}

export const DEFAULT_WS_CONFIG: WSConfig = {
  url: '',
  pingIntervalMs:  25_000,
  pongTimeoutMs:   10_000,
  maxRetriesByTier: {
    high:        10,
    normal:      10,
    low_compute:  5,
    critical:     2,
    dead:         0,  // no reconnect in dead tier — rely on HTTP polling only
  },
  baseBackoffMs:   500,
  maxBackoffMs:    60_000,
  jitterFactor:    0.3,
}

// ── State machine ─────────────────────────────────────────────────────────────

export type WSState =
  | 'idle'          // not started yet
  | 'connecting'    // connect() called, waiting for open event
  | 'connected'     // open + first pong received
  | 'reconnecting'  // disconnect detected, backing off before retry
  | 'offline'       // gave up on WS, HTTP polling is the only channel

export interface QueuedMessage {
  id:        string
  payload:   string
  queuedAt:  number
  attempts:  number
}

// ── WebSocketManager ──────────────────────────────────────────────────────────

export class WebSocketManager {
  private state: WSState = 'idle'
  private socket: WebSocket | null = null

  private pingTimer:      ReturnType<typeof setInterval> | null = null
  private pongTimer:      ReturnType<typeof setTimeout>  | null = null
  private reconnectTimer: ReturnType<typeof setTimeout>  | null = null

  private retryCount = 0
  private currentTier: SurvivalTier = 'normal'
  private messageHandlers: Array<(raw: string) => void> = []

  constructor(
    private readonly config: WSConfig,
    private readonly db: AutomatonDatabase,
  ) {
    // React to survival tier changes from the event bus
    bus.on('survival.tier.changed', ({ to }) => {
      this.currentTier = to
      this.onTierChanged(to)
    })

    // React to OS wake (Windows resume from sleep)
    // Node.js doesn't expose a native OS wake event, but we can poll
    // for a large time jump — if the monotonic clock jumps > 30s between
    // two setInterval ticks (which run at 1s), the machine likely slept.
    this.startSleepDetector()
  }

  // ── Public API ──────────────────────────────────────────────────────────────

  connect(): void {
    if (this.state === 'connected' || this.state === 'connecting') return
    if (this.currentTier === 'dead') {
      log.info('dead tier — skipping WebSocket, relying on HTTP polling')
      this.setState('offline')
      return
    }
    this.retryCount = 0
    this.doConnect()
  }

  disconnect(): void {
    this.clearTimers()
    if (this.socket) {
      this.socket.close(1000, 'client shutdown')
      this.socket = null
    }
    this.setState('idle')
  }

  /**
   * Send a message. If not connected, queues to SQLite for later delivery.
   */
  send(payload: string): void {
    if (this.state === 'connected' && this.socket?.readyState === WebSocket.OPEN) {
      try {
        this.socket.send(payload)
        return
      } catch (err) {
        log.warn('send failed, queuing', { err })
      }
    }
    this.enqueue(payload)
  }

  onMessage(handler: (raw: string) => void): () => void {
    this.messageHandlers.push(handler)
    return () => {
      this.messageHandlers = this.messageHandlers.filter(h => h !== handler)
    }
  }

  getState(): WSState  { return this.state }
  isConnected(): boolean { return this.state === 'connected' }

  // ── Internal connection flow ─────────────────────────────────────────────────

  private doConnect(): void {
    this.clearTimers()
    this.setState('connecting')

    try {
      this.socket = new WebSocket(this.config.url)
    } catch (err) {
      log.error('WebSocket constructor threw', { url: this.config.url, err })
      this.scheduleReconnect()
      return
    }

    this.socket.on('open', () => {
      log.info('WebSocket connected', { url: this.config.url, retries: this.retryCount })
      this.retryCount = 0
      this.setState('connected')
      this.startKeepalive()
      this.drainQueue()
      bus.emit('ollama.status.changed', {
        healthy: true, responseMs: 0, modelLoaded: false,
      })
    })

    this.socket.on('message', (data: WebSocket.RawData) => {
      const raw = data.toString()
      // Reset pong timer on ANY message — relays often send data instead of pong frames
      this.resetPongTimer()
      for (const handler of this.messageHandlers) {
        try { handler(raw) } catch (err) { log.error('message handler threw', { err }) }
      }
    })

    this.socket.on('pong', () => {
      this.resetPongTimer()
    })

    this.socket.on('close', (code, reason) => {
      const reasonStr = reason.toString()
      log.warn('WebSocket closed', { code, reason: reasonStr })
      this.onDisconnected(`closed: ${code} ${reasonStr}`)
    })

    this.socket.on('error', (err) => {
      log.error('WebSocket error', { err: err.message })
      this.onDisconnected(`error: ${err.message}`)
    })
  }

  private onDisconnected(reason: string): void {
    this.clearTimers()
    this.socket = null

    bus.emit('inference.failed', {
      error: reason,
      provider: 'social-relay-ws',
      consecutiveFailures: this.retryCount,
      willFallback: this.willGiveUp(),
    })

    if (this.willGiveUp()) {
      log.warn(`WebSocket giving up after ${this.retryCount} retries — switching to HTTP polling`)
      this.setState('offline')
      return
    }

    this.scheduleReconnect()
  }

  private scheduleReconnect(): void {
    this.setState('reconnecting')
    this.retryCount++

    // Exponential backoff: base × 2^(attempt-1), capped, with jitter
    const base   = this.config.baseBackoffMs * Math.pow(2, this.retryCount - 1)
    const capped = Math.min(base, this.config.maxBackoffMs)
    const jitter = capped * this.config.jitterFactor * Math.random()
    const delay  = Math.round(capped + jitter)

    log.info(`reconnect attempt ${this.retryCount} in ${delay}ms`)
    this.reconnectTimer = setTimeout(() => this.doConnect(), delay)
  }

  private willGiveUp(): boolean {
    const max = this.config.maxRetriesByTier[this.currentTier]
    return this.retryCount >= max
  }

  // ── Keepalive (ping/pong) ────────────────────────────────────────────────────

  private startKeepalive(): void {
    this.pingTimer = setInterval(() => this.sendPing(), this.config.pingIntervalMs)
  }

  private sendPing(): void {
    if (!this.socket || this.socket.readyState !== WebSocket.OPEN) return

    // Set a pong timeout: if we don't hear back in pongTimeoutMs, we're disconnected
    this.pongTimer = setTimeout(() => {
      log.warn('pong timeout — connection likely dropped by NAT/firewall')
      this.socket?.terminate()  // force-close without waiting for TCP RST
      this.onDisconnected('pong timeout')
    }, this.config.pongTimeoutMs)

    try {
      this.socket.ping()
    } catch (err) {
      log.warn('ping failed', { err })
    }
  }

  private resetPongTimer(): void {
    if (this.pongTimer) {
      clearTimeout(this.pongTimer)
      this.pongTimer = null
    }
  }

  // ── Message queue (SQLite persistence) ───────────────────────────────────────

  private enqueue(payload: string): void {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`
    this.db.run(
      `INSERT INTO ws_outbox (id, payload, queued_at, attempts) VALUES (?, ?, ?, 0)`,
      [id, payload, Date.now()]
    )
    log.debug('message queued to SQLite', { id })
  }

  /**
   * Send all queued messages on reconnect.
   * Messages that fail 3+ times are discarded.
   */
  private async drainQueue(): Promise<void> {
    if (this.state !== 'connected') return

    const rows = this.db.all<{ id: string; payload: string; attempts: number }>(
      `SELECT id, payload, attempts FROM ws_outbox ORDER BY queued_at ASC LIMIT 50`
    )

    for (const row of rows) {
      if (this.state !== 'connected') break
      try {
        this.socket!.send(row.payload)
        this.db.run(`DELETE FROM ws_outbox WHERE id = ?`, [row.id])
        log.debug('queued message delivered', { id: row.id })
      } catch {
        if (row.attempts >= 2) {
          log.warn('discarding undeliverable queued message', { id: row.id })
          this.db.run(`DELETE FROM ws_outbox WHERE id = ?`, [row.id])
        } else {
          this.db.run(`UPDATE ws_outbox SET attempts = attempts + 1 WHERE id = ?`, [row.id])
        }
      }
    }
  }

  // ── Tier-aware behavior ───────────────────────────────────────────────────────

  private onTierChanged(to: SurvivalTier): void {
    if (to === 'dead') {
      // In dead tier: close WS, rely entirely on HTTP polling (heartbeat task)
      log.warn('tier=dead — closing WebSocket to save resources')
      this.disconnect()
      this.setState('offline')
      return
    }

    if (to === 'critical' && this.state === 'offline') {
      // In critical: try once more to reconnect (funding alert might come via WS)
      log.info('tier=critical — attempting one WS reconnect for funding alerts')
      this.retryCount = 0
      this.doConnect()
      return
    }

    if ((to === 'normal' || to === 'high') && this.state === 'offline') {
      // Recovery: try reconnecting WS
      log.info(`tier=${to} — attempting WS reconnect after offline period`)
      this.retryCount = 0
      this.doConnect()
    }
  }

  // ── Sleep/wake detection ──────────────────────────────────────────────────────

  private startSleepDetector(): void {
    let lastTick = Date.now()
    setInterval(() => {
      const now = Date.now()
      const elapsed = now - lastTick
      lastTick = now

      // If the clock jumped more than 30s between 1s ticks, we likely slept
      if (elapsed > 30_000) {
        log.warn('OS sleep detected (clock jump)', { jumpMs: elapsed })
        if (this.state === 'connected') {
          // Connection is certainly dead after sleep
          this.socket?.terminate()
          this.onDisconnected('os-sleep-detected')
        }
      }
    }, 1_000)
  }

  // ── Utilities ────────────────────────────────────────────────────────────────

  private setState(s: WSState): void {
    if (s !== this.state) {
      log.debug(`ws state: ${this.state} → ${s}`)
      this.state = s
    }
  }

  private clearTimers(): void {
    if (this.pingTimer)      clearInterval(this.pingTimer)
    if (this.pongTimer)      clearTimeout(this.pongTimer)
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    this.pingTimer = this.pongTimer = this.reconnectTimer = null
  }
}
