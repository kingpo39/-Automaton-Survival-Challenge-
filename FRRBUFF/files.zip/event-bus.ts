/**
 * core/event-bus/index.ts
 *
 * Typed, in-process pub/sub event bus.
 *
 * WHY THIS EXISTS — the polling problem on constrained hardware:
 *
 * Without event bus (current architecture):
 *   Agent loop   polls DB every 30s for tier changes      ← SQLite read every 30s
 *   Heartbeat    polls DB every 60s for task triggers     ← SQLite read every 60s
 *   Brain        polls sensors every 30s unconditionally  ← even when everything stable
 *   Total: constant background I/O on 2-core machine, competes with inference
 *
 * With event bus:
 *   Brain EMITS  'survival.tier.changed' → heartbeat adjusts interval immediately
 *   Brain EMITS  'survival.critical'     → agent wakes without polling wake_events
 *   Balance read EMITS 'balance.restored' → agent resumes without 30s poll delay
 *   Inference EMITS 'inference.lock.released' → queued heartbeat task fires instantly
 *   Total: 0 polling overhead between components — pure event-driven
 *
 * Design decisions:
 *   - Synchronous dispatch (no async): listeners run before emit() returns.
 *     On a 2-core machine, async event queues add scheduling overhead.
 *     Listeners are expected to be fast (<1ms); heavy work is deferred by the listener.
 *   - Typed: TypeScript enforces payload shapes at compile time.
 *   - Singleton: one bus per process, imported everywhere.
 *   - No external dependencies: built on EventEmitter from Node.js stdlib.
 */

import { EventEmitter } from 'events'
import { createLogger } from '../../observability/logger'

const log = createLogger('core:event-bus')

// ── Event catalog ─────────────────────────────────────────────────────────────

export type SurvivalTier = 'high' | 'normal' | 'low_compute' | 'critical' | 'dead'
export type RouteDecision = 'trivial' | 'normal' | 'complex'

export interface BusEvents {
  // ── Survival tier ──────────────────────────────────────────────────────
  'survival.tier.changed': {
    from:   SurvivalTier
    to:     SurvivalTier
    reason: string
    urgency: 'routine' | 'immediate' | 'emergency'
  }
  'survival.critical': {
    reason:      string
    usdcBalance: number
    ramFreeMB:   number
  }
  'survival.dead': {
    reason:       string
    criticalForMs: number   // how long we were critical before dying
  }
  'survival.recovered': {
    from:        SurvivalTier
    usdcBalance: number
  }

  // ── Financial ──────────────────────────────────────────────────────────
  'balance.restored': {
    amount:     number     // USDC added
    newBalance: number
    source:     string     // 'inbound_transfer' | 'detected_increase'
  }
  'balance.depleted': {
    balance:    number
    tier:       SurvivalTier
    burnRatePerDay: number
  }
  'spend.approved': {
    toolName:    string
    amountUSDC:  number
    valueScore:  number
  }
  'spend.denied': {
    toolName:    string
    amountUSDC:  number
    reason:      string
  }

  // ── Inference ──────────────────────────────────────────────────────────
  'inference.lock.acquired': {
    caller:     string
    provider:   'omniroute' | 'ollama' | 'none'  // 'none' = trivial route
  }
  'inference.lock.released': {
    caller:       string
    durationMs:   number
    tokensOut:    number
    route:        RouteDecision
  }
  'inference.failed': {
    error:              string
    provider:           string
    consecutiveFailures: number
    willFallback:       boolean
  }
  'inference.fallback': {
    from:   string    // omniroute
    to:     string    // ollama
    reason: string
  }

  // ── Agent lifecycle ────────────────────────────────────────────────────
  'agent.waking': {
    reason:  string
    source:  string   // 'wake_event' | 'timer' | 'balance_restored'
  }
  'agent.sleeping': {
    reason:   string
    idleTurns: number
  }
  'agent.turn.completed': {
    toolsUsed: string[]
    phase:     string
    route:     RouteDecision
    durationMs: number
  }
  'agent.turn.failed': {
    error: string
    turn:  number
  }

  // ── Heartbeat ──────────────────────────────────────────────────────────
  'heartbeat.task.completed': {
    task:       string
    shouldWake: boolean
    durationMs: number
  }
  'heartbeat.task.skipped': {
    task:   string
    reason: 'inference_lock_held' | 'tier_too_low' | 'lease_held'
  }
  'heartbeat.interval.changed': {
    from: number
    to:   number
    tier: SurvivalTier
  }

  // ── RAM / compute ──────────────────────────────────────────────────────
  'compute.pressure.changed': {
    from:      'none' | 'moderate' | 'severe' | 'critical'
    to:        'none' | 'moderate' | 'severe' | 'critical'
    freeMB:    number
  }
  'ollama.status.changed': {
    healthy:     boolean
    responseMs:  number
    modelLoaded: boolean
  }

  // ── Child / replication ────────────────────────────────────────────────
  'child.spawned': {
    childId:      string
    fundedUSDC:   number
    containerName: string
  }
  'child.died': {
    childId: string
    reason:  string
  }
  'child.recovered': {
    childId: string
  }
}

// ── EventBus class ────────────────────────────────────────────────────────────

type EventName    = keyof BusEvents
type EventPayload<E extends EventName> = BusEvents[E]
type Listener<E extends EventName>     = (payload: EventPayload<E>) => void

class TypedEventBus {
  private readonly emitter = new EventEmitter()
  private eventCount = 0

  constructor() {
    // High listener limit — this bus serves many subsystems
    this.emitter.setMaxListeners(50)
  }

  /**
   * Emit an event. All listeners run synchronously before emit() returns.
   * Keep listeners fast; defer heavy work with setImmediate() inside the listener.
   */
  emit<E extends EventName>(event: E, payload: EventPayload<E>): void {
    this.eventCount++
    log.debug(`emit:${event}`, { payload })
    this.emitter.emit(event, payload)
  }

  /**
   * Subscribe to an event. Returns an unsubscribe function.
   */
  on<E extends EventName>(event: E, listener: Listener<E>): () => void {
    this.emitter.on(event, listener as (p: unknown) => void)
    return () => this.emitter.off(event, listener as (p: unknown) => void)
  }

  /**
   * Subscribe for ONE emission only. Auto-unsubscribes after first call.
   */
  once<E extends EventName>(event: E, listener: Listener<E>): () => void {
    this.emitter.once(event, listener as (p: unknown) => void)
    return () => this.emitter.off(event, listener as (p: unknown) => void)
  }

  /**
   * Wait for an event (Promise-based). Useful in async bootstrap sequences.
   * Resolves on first emission.
   */
  waitFor<E extends EventName>(event: E, timeoutMs = 30_000): Promise<EventPayload<E>> {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error(`Timeout waiting for event: ${event}`))
      }, timeoutMs)

      this.emitter.once(event, (payload: unknown) => {
        clearTimeout(timer)
        resolve(payload as EventPayload<E>)
      })
    })
  }

  /**
   * Diagnostic: number of events emitted since startup.
   */
  get totalEvents(): number { return this.eventCount }
}

// ── Singleton ─────────────────────────────────────────────────────────────────

export const bus = new TypedEventBus()

// ── Convenience helpers ───────────────────────────────────────────────────────

/** Emit a survival tier change. Used by SurvivalBrain only. */
export function emitTierChange(
  from: SurvivalTier,
  to:   SurvivalTier,
  reason: string,
  urgency: BusEvents['survival.tier.changed']['urgency'],
): void {
  bus.emit('survival.tier.changed', { from, to, reason, urgency })
  if (to === 'critical') bus.emit('survival.critical', {
    reason,
    usdcBalance: 0,  // caller fills in actual balance
    ramFreeMB: 0,
  })
  if (to === 'dead') bus.emit('survival.dead', {
    reason,
    criticalForMs: 0,  // caller fills in
  })
}
