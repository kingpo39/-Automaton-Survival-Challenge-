/**
 * platform/connection-health.ts
 *
 * Dual-path connection health monitor.
 *
 * The survival agent uses TWO communication paths to the social relay:
 *   1. WebSocket (primary) — fast, real-time, can disconnect
 *   2. HTTP polling (fallback) — slow, always works, never "disconnects"
 *
 * This module makes the HTTP polling path SMARTER:
 *   - Increases poll frequency when WS is offline (so nothing is missed)
 *   - Decreases poll frequency when WS is healthy (no need for redundant requests)
 *   - Always polls more aggressively during critical/dead states
 *     (those are the moments when a USDC inbound transfer matters most)
 *
 * The heartbeat task 'check_social_inbox' calls this module to get its
 * target interval instead of using a fixed cron expression.
 *
 * This is the GUARANTEED channel. Even if WebSocket is completely broken,
 * the agent will still receive funding alerts and social messages
 * within MAX_POLL_INTERVAL_MS.
 */

import type { WSState } from './ws-manager'
import type { SurvivalTier } from '../core/event-bus/index'
import { createLogger } from '../observability/logger'

const log = createLogger('platform:connection-health')

export interface ConnectionStatus {
  wsState:           WSState
  wsConnectedMs:     number        // how long WS has been connected; 0 if not
  httpPollIntervalMs: number       // recommended poll interval right now
  lastHttpPollMs:    number        // ms since last HTTP poll
  lastMessageMs:     number        // ms since last message received (any channel)
  overallHealthy:    boolean
  channel:           'websocket' | 'http_polling' | 'both' | 'none'
}

// Poll intervals (ms) by tier + WS state
// Logic: poll more when (a) WS is down, (b) tier is low, or both
const POLL_INTERVALS: Record<SurvivalTier, { wsUp: number; wsDown: number }> = {
  high:        { wsUp: 5 * 60_000, wsDown: 2 * 60_000 },  // 5 min / 2 min
  normal:      { wsUp: 5 * 60_000, wsDown: 2 * 60_000 },
  low_compute: { wsUp: 2 * 60_000, wsDown: 1 * 60_000 },  // 2 min / 1 min
  critical:    { wsUp: 1 * 60_000, wsDown: 30_000 },       // 1 min / 30 sec — USDC alerts critical
  dead:        { wsUp: 60_000,     wsDown: 60_000 },       // dead tier: WS is off, poll every 60s
}

export class ConnectionHealthMonitor {
  private wsConnectedSince: number | null = null
  private lastHttpPoll = 0
  private lastMessage  = 0

  constructor(
    private readonly wsManager: { getState: () => WSState },
    private readonly getSurvivalTier: () => SurvivalTier,
  ) {}

  onWSConnected(): void    { this.wsConnectedSince = Date.now() }
  onWSDisconnected(): void { this.wsConnectedSince = null }
  onMessageReceived(): void { this.lastMessage = Date.now() }
  onHttpPollCompleted(): void { this.lastHttpPoll = Date.now() }

  /**
   * Called by the heartbeat scheduler before running 'check_social_inbox'.
   * Returns true if it's time to poll (the task is due).
   */
  shouldPollNow(): boolean {
    const interval = this.getRecommendedPollIntervalMs()
    return Date.now() - this.lastHttpPoll >= interval
  }

  /**
   * The poll interval the heartbeat task should use.
   * Replaces the fixed cron expression for check_social_inbox.
   */
  getRecommendedPollIntervalMs(): number {
    const tier    = this.getSurvivalTier()
    const wsState = this.wsManager.getState()
    const wsUp    = wsState === 'connected'

    const intervals = POLL_INTERVALS[tier]
    return wsUp ? intervals.wsUp : intervals.wsDown
  }

  getStatus(): ConnectionStatus {
    const wsState = this.wsManager.getState()
    const tier    = this.getSurvivalTier()
    const wsUp    = wsState === 'connected'

    const wsConnectedMs = this.wsConnectedSince ? Date.now() - this.wsConnectedSince : 0
    const httpPollIntervalMs = this.getRecommendedPollIntervalMs()
    const lastHttpPollMs = this.lastHttpPoll > 0 ? Date.now() - this.lastHttpPoll : Infinity
    const lastMessageMs  = this.lastMessage  > 0 ? Date.now() - this.lastMessage  : Infinity

    const channel: ConnectionStatus['channel'] =
      wsUp && lastHttpPollMs < httpPollIntervalMs * 2 ? 'both' :
      wsUp    ? 'websocket' :
      lastHttpPollMs < httpPollIntervalMs * 2 ? 'http_polling' :
      'none'

    const overallHealthy = channel !== 'none'

    if (!overallHealthy) {
      log.warn('no communication channel active', { wsState, lastHttpPollMs, tier })
    }

    return {
      wsState,
      wsConnectedMs,
      httpPollIntervalMs,
      lastHttpPollMs,
      lastMessageMs,
      overallHealthy,
      channel,
    }
  }
}
