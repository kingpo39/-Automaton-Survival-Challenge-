/**
 * core/router/survival-fsm.ts
 *
 * Finite State Machine with HYSTERESIS for survival tier transitions.
 *
 * THE OSCILLATION PROBLEM (why this is needed):
 *
 * Without hysteresis, consider USDC hovering around $10:
 *   T+0s:  $10.02  → normal   (tier assigned)
 *   T+30s: $9.98   → low_compute (tier transition fires!)
 *   T+60s: $10.01  → normal   (tier transition fires again!)
 *   T+90s: $9.99   → low_compute (again...)
 *
 * On a 2-core machine this matters because every tier transition:
 *   - Emits events (CPU)
 *   - Updates the DB (I/O)
 *   - May change heartbeat interval (timer reset overhead)
 *   - May emit distress signals (network I/O)
 *   - Disrupts the agent loop's behavior
 *
 * SOLUTION — HYSTERESIS BANDS:
 *
 * Each tier boundary has TWO thresholds instead of one:
 *   - ENTRY threshold: score must FALL below this to trigger downgrade
 *   - EXIT threshold:  score must RISE above this to trigger upgrade
 *
 * The gap between entry and exit is the "dead zone" — a range where
 * no tier transition fires. The agent stays in its current tier even
 * as the score fluctuates within the dead zone.
 *
 * Example with normalized scores (0.0 = worst, 1.0 = best):
 *   current = normal (score ~0.60)
 *   Entry threshold for low_compute = 0.45  (score must fall to 0.45 to trigger)
 *   Exit  threshold from low_compute = 0.55  (score must rise to 0.55 to exit)
 *   Dead zone: [0.45, 0.55] — no transitions in this band
 *
 * The result: score must move meaningfully and sustain the change
 * before the FSM transitions. Noise and small fluctuations are ignored.
 */

import type { SurvivalTier } from '../event-bus/index'

// ── Hysteresis band definitions ───────────────────────────────────────────────
//
// For each tier, defines the composite score range in which that tier is active.
// 'enter' = the score must be AT OR BELOW this to enter the tier (from a higher tier)
// 'exit'  = the score must be AT OR ABOVE this to exit the tier (to a higher tier)
//
// These bands deliberately OVERLAP so that the transition between tiers requires
// a meaningful score change, not a minor fluctuation.
//
// Tuned for real-money mainnet on constrained hardware:
//   - Financial: $50=high, $10=normal, $2=low_compute, $0.01=critical (hard thresholds)
//   - The normalized scores below create ~0.10 dead zones between tier boundaries

export const HYSTERESIS_BANDS: Record<SurvivalTier, { enter: number; exit: number }> = {
  high:        { enter: 0.85, exit: 0.80 },  // enter high at 0.85+, fall back below 0.80
  normal:      { enter: 0.55, exit: 0.50 },  // enter normal at 0.55+, fall below 0.50
  low_compute: { enter: 0.25, exit: 0.35 },  // enter low_compute below 0.25 (inverted), exit above 0.35
  critical:    { enter: 0.10, exit: 0.20 },  // enter critical below 0.10, exit above 0.20
  dead:        { enter: 0.00, exit: 0.05 },  // enter dead at 0 (grace period), exit above 0.05
}

// Tier ordering (higher = better)
const TIER_ORDER: SurvivalTier[] = ['dead', 'critical', 'low_compute', 'normal', 'high']
const TIER_RANK: Record<SurvivalTier, number> = {
  dead: 0, critical: 1, low_compute: 2, normal: 3, high: 4
}

// ── SurvivalFSM ───────────────────────────────────────────────────────────────

export class SurvivalFSM {
  private currentTier: SurvivalTier = 'normal'
  private currentScore = 0.6          // starting assumption
  private ticksInCurrentTier = 0
  private readonly MIN_TICKS_BEFORE_UPGRADE = 2  // must hold improved score for 2 ticks

  constructor(initialTier?: SurvivalTier) {
    if (initialTier) this.currentTier = initialTier
  }

  getCurrentTier(): SurvivalTier { return this.currentTier }
  getCurrentScore(): number       { return this.currentScore }
  getTicksInTier(): number        { return this.ticksInCurrentTier }

  /**
   * Feed a new composite score (0.0 = worst, 1.0 = best) and any hard constraints.
   * Returns the new tier (may be the same as current if no transition fired).
   *
   * Hard constraints (like DB dead, RAM < 512 MB) can override the score
   * and force a specific tier regardless of the composite.
   */
  evaluate(score: number, hardConstrainedTier?: SurvivalTier): {
    tier: SurvivalTier
    transitioned: boolean
    previousTier: SurvivalTier
    reason: string
  } {
    this.currentScore = score
    const previous = this.currentTier

    // Hard constraints take precedence — no hysteresis on safety-critical conditions
    if (hardConstrainedTier !== undefined) {
      const changed = hardConstrainedTier !== this.currentTier
      if (changed) {
        this.ticksInCurrentTier = 0
        this.currentTier = hardConstrainedTier
        return {
          tier: this.currentTier,
          transitioned: true,
          previousTier: previous,
          reason: `hard constraint → ${hardConstrainedTier}`,
        }
      }
      this.ticksInCurrentTier++
      return { tier: this.currentTier, transitioned: false, previousTier: previous, reason: 'hard constraint unchanged' }
    }

    const currentRank = TIER_RANK[this.currentTier]
    let newTier = this.currentTier

    // Check if score has degraded enough to move DOWN
    const degradedTier = this.findDegradedTier(score, this.currentTier)
    if (degradedTier && TIER_RANK[degradedTier] < currentRank) {
      // Downgrades fire immediately — no minimum tick requirement (safety first)
      newTier = degradedTier
    }

    // Check if score has improved enough to move UP
    const improvedTier = this.findImprovedTier(score, this.currentTier)
    if (improvedTier && TIER_RANK[improvedTier] > currentRank) {
      // Upgrades require MIN_TICKS_BEFORE_UPGRADE ticks in the improved range (anti-flap)
      if (this.ticksInCurrentTier >= this.MIN_TICKS_BEFORE_UPGRADE) {
        newTier = improvedTier
      }
      // else: score is better but we haven't sustained it long enough yet
    }

    const transitioned = newTier !== this.currentTier
    if (transitioned) {
      this.ticksInCurrentTier = 0
      this.currentTier = newTier
    } else {
      this.ticksInCurrentTier++
    }

    return {
      tier: this.currentTier,
      transitioned,
      previousTier: previous,
      reason: transitioned
        ? `score ${score.toFixed(3)} crossed hysteresis band → ${newTier}`
        : `score ${score.toFixed(3)} within dead zone, staying ${this.currentTier} (tick ${this.ticksInCurrentTier})`,
    }
  }

  /**
   * Would the score trigger a tier downgrade from current?
   * Returns the worst tier the score qualifies for, or null.
   */
  private findDegradedTier(score: number, current: SurvivalTier): SurvivalTier | null {
    // Walk from worst to current; find worst tier whose entry threshold the score has crossed
    for (const tier of TIER_ORDER) {
      if (TIER_RANK[tier] >= TIER_RANK[current]) break  // don't check same or better tiers

      // Dead and critical are inverted: score must be very LOW to enter them
      // Normal and high: score must be sufficiently HIGH to be above them
      const band = HYSTERESIS_BANDS[tier]

      if (TIER_RANK[tier] <= TIER_RANK['critical']) {
        // Low tiers: entered when score drops AT OR BELOW entry threshold
        if (score <= band.enter) return tier
      }
    }
    return null
  }

  /**
   * Would the score trigger an upgrade from current?
   * Returns the best tier the score qualifies for, or null.
   */
  private findImprovedTier(score: number, current: SurvivalTier): SurvivalTier | null {
    // Walk from best to current; find best tier the score has crossed the EXIT threshold for
    for (let i = TIER_ORDER.length - 1; i >= 0; i--) {
      const tier = TIER_ORDER[i]
      if (TIER_RANK[tier] <= TIER_RANK[current]) break  // don't check same or worse tiers

      const band = HYSTERESIS_BANDS[tier]
      if (score >= band.exit) return tier
    }
    return null
  }

  /** Reset to a known tier (e.g., after loading from DB on restart) */
  reset(tier: SurvivalTier, score?: number): void {
    this.currentTier = tier
    this.ticksInCurrentTier = 0
    if (score !== undefined) this.currentScore = score
  }
}
