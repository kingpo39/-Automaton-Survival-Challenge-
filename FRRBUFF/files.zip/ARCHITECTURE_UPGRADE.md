# Architecture Upgrade — Conway Reference + OmniRoute + Constrained Hardware

---

## First: What OmniRoute Actually Is

OmniRoute@3.8.49 is NOT a model.
It is a FREE, open-source AI gateway (npm package, MIT license) that provides
ONE OpenAI-compatible local endpoint in front of 290+ AI providers
(90+ with free tiers, 40+ free forever) with:
  - Quota-aware auto-fallback (exhausts one provider → switches silently)
  - RTK+Caveman compression (saves 15-95% tokens before sending)
  - 18 routing strategies (best-coding, best-free, lowest-latency, etc.)
  - MCP server (104 tools), A2A v0.3 protocol
  - Auto intent-routing: auto/best-coding, auto/best-free

This changes everything about the inference architecture.

---

## Model Recommendation (Hard Numbers)

Hardware: i3-10110U · 7.84 GB RAM · CPU-only · num_ctx 8192

  Model              Q4 size  KV@8192  Total Ollama  Headroom  Tool Call
  ─────────────────────────────────────────────────────────────────────
  Qwen2.5-Coder 3B   1.93 GB  281 MB   2.71 GB      +2.08 GB  Native ✓✓✓
  Gemma 4 E2B        0.90 GB  141 MB   1.54 GB      +3.25 GB  Native ✓✓
  Llama 3.2 3B       1.90 GB  875 MB   3.27 GB      +1.52 GB  Native ✓✓
  Phi-4 Mini 3.8B    2.20 GB  750 MB   3.45 GB      +1.34 GB  Native ✓✓
  Gemma 3 1B         0.67 GB  141 MB   1.31 GB      +3.48 GB  Needs FT ✗
  Phi-3 Mini 3.8B    2.20 GB  3.0 GB   5.70 GB      -0.91 GB  IMPOSSIBLE ✗✗

KEY FINDINGS:
  - Phi-3 Mini: physically CANNOT run at 8192 ctx (KV cache alone = 3 GB, OOM)
  - Gemma 3 1B: needs fine-tuning for tool calling. Out-of-box = unreliable JSON
  - Gemma 4 E2B: native function calling, very light — good secondary fallback
  - Qwen2.5-Coder 3B: still BEST local-only choice (unique 2 KV head architecture)
  - Llama 3.2 3B: decent alternative but 3× more KV cache than Qwen

VERDICT: Use a THREE-LAYER model stack:
  1. OmniRoute → cloud free tiers (primary, fast, no RAM cost)
  2. Qwen2.5-Coder 3B via Ollama (offline fallback)
  3. Gemma 4 E2B via Ollama (dead-state ultra-fallback, only 1.54 GB)

OmniRoute RAM profile:
  Online (OmniRoute, no model loaded):  4.25 GB FREE
  Offline (Qwen2.5-Coder 3B loaded):   1.52 GB FREE
  Dead-state (Gemma 4 E2B loaded):      2.63 GB FREE

---

## What the Conway Reference Adds (Prioritized by Hardware Impact)

PRIORITY 1 — IMMEDIATE EFFICIENCY GAINS (implement first)
  ✓ src/core/event-bus/          In-process typed pub/sub: eliminates polling
  ✓ src/core/router/survival-fsm  FSM with hysteresis: prevents tier oscillation
  ✓ src/core/router/state-vector   Continuous 0-1 scoring: smoother behavior
  ✓ src/core/router/index          DETERMINISTIC ROUTER: skips LLM for 65% of tasks
  ✓ src/survival/packet-capture    Signal history ring buffer: enables correlation

PRIORITY 2 — INTELLIGENCE (implement after P1 is stable)
  ✓ src/core/forecast/             Predicts USDC exhaustion days in advance
  ✓ src/core/budget/               Value-per-dollar spend decisions
  ✓ src/platform/omniroute-client  OmniRoute + offline fallback chain

PRIORITY 3 — SKIP FOR THIS HARDWARE
  ✗ src/engines/insight/           22-language sentiment: too heavy for CPU
  ✗ src/engines/spider/            7-platform crawler: network + CPU heavy
  ✗ src/engines/media/             Multimodal: requires cloud/GPU
  ✗ src/knowledge/                 Network-heavy domain tracking
  ✗ src/engines/forum/             LLM-heavy discussion moderator
  (keep src/engines/report/ but run it sequentially, not as a parallel graph)

---

## The Deterministic Router: Biggest Single Efficiency Gain

The Conway reference's src/core/router/index.ts classifies EVERY incoming
work request BEFORE it reaches any inference provider.

Estimated distribution on typical agent workloads:
  ~65% TRIVIAL  → direct code execution, no model call at all
  ~25% NORMAL   → OmniRoute fast model (Groq Llama 70B, ~1s response)
  ~10% COMPLEX  → OmniRoute best model (Gemini 2.5 Flash, 1-3s response)

On current spec (everything through full ReAct loop):
  Average turn time: 20-180 seconds (CPU inference)
  100 agent actions/day = 33-300 minutes of inference time

With deterministic router + OmniRoute:
  65 trivial → 0 seconds (code execution)
  25 normal  → ~25 seconds (Groq free tier, 1s × 25)
  10 complex → ~30 seconds (Gemini free, 3s × 10)
  Total: ~55 seconds for 100 actions vs 33-300 minutes
  Speedup: 36x-327x

This is not an incremental improvement. This is a different architecture.

---

## Updated Directory Structure

src/
  ├── core/                         ← NEW: Neural system (μs decisions)
  │   ├── event-bus/index.ts            Typed pub/sub — eliminates polling
  │   ├── router/
  │   │   ├── survival-fsm.ts           FSM + hysteresis bands
  │   │   ├── state-vector.ts           Continuous 0-1 health scoring
  │   │   └── index.ts                  Deterministic router: trivial/normal/complex
  │   ├── forecast/index.ts             USDC exhaustion + RAM trend prediction
  │   ├── budget/index.ts               Value-per-dollar task prioritization
  │   └── index.ts                      Core barrel export
  │
  ├── survival/                     ← ENHANCED
  │   ├── brain.ts                      (updated: uses state-vector + FSM)
  │   ├── sensors/index.ts
  │   ├── tiers/evaluator.ts            (updated: feeds state-vector, not worst-signal)
  │   ├── tiers/behaviors.ts
  │   ├── actuators/index.ts
  │   ├── packet-capture.ts         ← NEW: Wireshark-like signal ring buffer
  │   ├── funding.ts                ← NEW: Structured distress + funding requests
  │   ├── low-compute.ts            ← NEW: Detailed reduced-mode configuration
  │   └── monitor.ts                ← NEW: External monitoring interface
  │
  ├── platform/                     ← ENHANCED
  │   ├── omniroute-client.ts       ← NEW: OmniRoute + fallback chain
  │   ├── ollama-client.ts              (kept as offline fallback)
  │   ├── docker-sandbox.ts
  │   ├── x402.ts
  │   ├── treasury.ts
  │   └── testnet.ts
  │
  ├── agent/                        ← UPDATED: uses deterministic router
  │   ├── loop.ts                       (updated: router classifies before LLM)
  │   ├── tools.ts                      (69 tools — 12 more than current spec)
  │   ├── tool-registry.ts
  │   ├── context.ts
  │   ├── injection-defense.ts
  │   ├── policy-engine.ts
  │   ├── spend-tracker.ts
  │   └── system-prompt.ts
  │
  └── ... (rest unchanged from current spec)

---

## OmniRoute Free Tier Stack (Best Combos for This Project)

Install: npm install -g omniroute
Start:   omniroute (runs on localhost:20128)
Config:  ollamaUrl: "http://localhost:20128/v1"  ← same OpenAI-compatible API

Free forever providers for agent/coding work:
  Groq      groq/      Llama 3.3 70B, Gemma 2 9B — 14,400 req/day, ultra-fast
  Gemini    gemini/    Gemini 2.5 Flash — 1,500 req/day free API key
  Cloudflare cf/       Llama 3.2 3B, Gemma 3 — 10K neurons/day
  Pollinations pol/    GPT-5, Claude, DeepSeek, Llama 4 — no key needed
  NVIDIA NIM nvidia/   70+ open models — 40 RPM forever

Recommended combo for this agent:
  1. groq/llama-3.3-70b-versatile  (normal tasks — fast, 70B reasoning)
  2. gemini/gemini-2.5-flash       (complex tasks — best free quality)
  3. cf/llama-3.3-70b              (backup when Groq quota exhausted)
  4. pol/openai                    (emergency fallback, no key)
  5. LOCAL: qwen2.5-coder:3b      (offline fallback via Ollama)
  6. LOCAL: gemma4:e2b             (dead-state ultra-fallback)

RTK+Caveman compression: saves 30-50% tokens on agent prompts
→ Your 8192-token context budget effectively becomes 12K-16K for free

