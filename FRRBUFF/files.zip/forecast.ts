/**
 * core/forecast/index.ts
 *
 * Resource exhaustion prediction.
 *
 * Transforms the agent from REACTIVE to PROACTIVE:
 *
 *   REACTIVE (current):
 *     "USDC balance is $1.80. Entering low_compute."   ← already a problem
 *
 *   PROACTIVE (with forecast):
 *     "At current burn rate ($0.80/day), USDC hits low_compute in 10 days.
 *      Recommend reducing x402 spend or requesting funding."   ← time to act
 *
 * Uses signal history from PacketCapture to compute:
 *   1. Financial: linear regression on balance over time → burn rate → days-to-threshold
 *   2. Compute:   moving average of RAM free → trend → predicted pressure onset
 *
 * Output is injected into the system prompt's financial state block,
 * giving the agent forward-looking context without requiring an inference call
 * (all math is deterministic Python/TS).
 */

export interface ResourceForecast {
  // ── Financial ──────────────────────────────────────────────────────────────
  currentBalance:          number    // USDC
  dailyBurnRate:           number    // USDC/day (negative = earning, positive = spending)
  daysUntilLowCompute:     number    // Infinity if burn rate is 0 or improving
  daysUntilCritical:       number
  daysUntilDead:           number
  financialTrajectory:     FinancialTrajectory
  financialConfidence:     number    // 0-1: based on how many readings available

  // ── Compute ────────────────────────────────────────────────────────────────
  currentRamFreeMB:        number
  ramTrend:                RamTrend
  predictedSevereInHours:  number | null  // null = not predicted within 24h
  computeConfidence:       number

  // ── Signal correlations ────────────────────────────────────────────────────
  correlations:            SignalCorrelation[]

  // ── Summary ────────────────────────────────────────────────────────────────
  summary:                 string    // 1-2 sentences for system prompt injection
  recommendations:         string[]  // actionable items for the agent
  basedOnNReadings:        number
  forecastTimestamp:       number
}

export type FinancialTrajectory = 'stable' | 'recovering' | 'depleting_slowly' | 'depleting_fast' | 'critical_soon'
export type RamTrend             = 'stable' | 'improving' | 'degrading_slowly' | 'degrading_fast'

export interface SignalCorrelation {
  signal1: string
  signal2: string
  description: string   // human-readable: "RAM pressure precedes Ollama slowdown by ~2 ticks"
  strength:    number   // 0-1
}

// Survival tier USDC thresholds (from config)
const THRESHOLDS = {
  high:        50.0,
  normal:      10.0,
  low_compute: 2.0,
  critical:    0.01,
}

// ── ResourceForecaster ────────────────────────────────────────────────────────

export class ResourceForecaster {
  /**
   * Generate a forecast from the packet capture history.
   * @param history Array of [timestamp_ms, usdcBalance, ramFreeMB, ollamaResponseMs]
   */
  forecast(history: Array<{
    ts:            number
    usdcBalance:   number
    ramFreeMB:     number
    ollamaResponseMs: number
  }>): ResourceForecast {
    if (history.length === 0) {
      return this.emptyForecast()
    }

    const sorted    = [...history].sort((a, b) => a.ts - b.ts)
    const latest    = sorted[sorted.length - 1]
    const financial = this.forecastFinancial(sorted)
    const compute   = this.forecastCompute(sorted)
    const corrs     = this.detectCorrelations(sorted)

    const summary   = this.buildSummary(financial, compute, latest.usdcBalance)
    const recs      = this.buildRecommendations(financial, compute)

    return {
      currentBalance:      latest.usdcBalance,
      dailyBurnRate:       financial.burnRate,
      daysUntilLowCompute: financial.daysToThreshold(THRESHOLDS.low_compute),
      daysUntilCritical:   financial.daysToThreshold(THRESHOLDS.critical),
      daysUntilDead:       financial.daysToThreshold(0),
      financialTrajectory: financial.trajectory,
      financialConfidence: financial.confidence,

      currentRamFreeMB:       latest.ramFreeMB,
      ramTrend:               compute.trend,
      predictedSevereInHours: compute.hoursUntilSevere,
      computeConfidence:      compute.confidence,

      correlations:   corrs,
      summary,
      recommendations: recs,
      basedOnNReadings: sorted.length,
      forecastTimestamp: Date.now(),
    }
  }

  // ── Financial regression ──────────────────────────────────────────────────

  private forecastFinancial(
    readings: Array<{ ts: number; usdcBalance: number }>
  ): {
    burnRate: number
    trajectory: FinancialTrajectory
    confidence: number
    daysToThreshold: (threshold: number) => number
    latestBalance: number
  } {
    if (readings.length < 3) {
      return {
        burnRate: 0,
        trajectory: 'stable',
        confidence: 0,
        daysToThreshold: () => Infinity,
        latestBalance: readings[readings.length - 1]?.usdcBalance ?? 0,
      }
    }

    const latest = readings[readings.length - 1]

    // Use readings from last 7 days only for burn rate calculation
    const cutoff7d = latest.ts - 7 * 24 * 3600 * 1000
    const recent   = readings.filter(r => r.ts >= cutoff7d)
    const window   = recent.length >= 3 ? recent : readings

    // Linear regression: balance = slope × time + intercept
    // slope in USDC/ms → convert to USDC/day
    const { slope, r2 } = linearRegression(
      window.map(r => r.ts),
      window.map(r => r.usdcBalance),
    )

    const burnRatePerDay = -slope * 86_400_000  // positive = spending, negative = earning

    const trajectory: FinancialTrajectory =
      burnRatePerDay < 0  ? 'recovering' :
      burnRatePerDay < 0.20 ? 'stable' :
      burnRatePerDay < 1.00 ? 'depleting_slowly' :
      burnRatePerDay < 5.00 ? 'depleting_fast' :
                               'critical_soon'

    const daysToThreshold = (threshold: number): number => {
      if (burnRatePerDay <= 0) return Infinity          // not spending or earning
      const diff = latest.usdcBalance - threshold
      if (diff <= 0) return 0                           // already there
      return diff / burnRatePerDay
    }

    return {
      burnRate: burnRatePerDay,
      trajectory,
      confidence: Math.min(1, r2 * (window.length / 20)),  // scale by sample size
      daysToThreshold,
      latestBalance: latest.usdcBalance,
    }
  }

  // ── Compute trend ─────────────────────────────────────────────────────────

  private forecastCompute(
    readings: Array<{ ts: number; ramFreeMB: number }>
  ): {
    trend: RamTrend
    hoursUntilSevere: number | null
    confidence: number
  } {
    if (readings.length < 5) {
      return { trend: 'stable', hoursUntilSevere: null, confidence: 0 }
    }

    const latest = readings[readings.length - 1]
    const cutoff2h = latest.ts - 2 * 3600 * 1000
    const recent = readings.filter(r => r.ts >= cutoff2h)

    if (recent.length < 3) {
      return { trend: 'stable', hoursUntilSevere: null, confidence: 0 }
    }

    const { slope, r2 } = linearRegression(
      recent.map(r => r.ts),
      recent.map(r => r.ramFreeMB),
    )

    // slope in MB/ms → MB/hour
    const slopePerHour = slope * 3_600_000

    const trend: RamTrend =
      slopePerHour > 50   ? 'improving' :
      slopePerHour > -20  ? 'stable' :
      slopePerHour > -100 ? 'degrading_slowly' :
                             'degrading_fast'

    // Predict when RAM will hit "severe" threshold (< 1,024 MB free)
    const SEVERE_THRESHOLD_MB = 1_024
    let hoursUntilSevere: number | null = null

    if (slopePerHour < 0 && latest.ramFreeMB > SEVERE_THRESHOLD_MB) {
      const hoursToSevere = (latest.ramFreeMB - SEVERE_THRESHOLD_MB) / (-slopePerHour)
      if (hoursToSevere < 24) {  // only report if within 24h
        hoursUntilSevere = hoursToSevere
      }
    }

    return {
      trend,
      hoursUntilSevere,
      confidence: Math.min(1, r2 * (recent.length / 10)),
    }
  }

  // ── Correlation detection ─────────────────────────────────────────────────

  private detectCorrelations(
    readings: Array<{ ts: number; ramFreeMB: number; ollamaResponseMs: number }>
  ): SignalCorrelation[] {
    const corrs: SignalCorrelation[] = []

    if (readings.length < 10) return corrs

    // Check if RAM drop precedes Ollama slowdown (common pattern: memory pressure → swap → latency)
    const rams  = readings.map(r => r.ramFreeMB)
    const olls  = readings.map(r => r.ollamaResponseMs).filter(v => v > 0)

    if (olls.length >= 10) {
      const ramOllCorr = pearsonCorrelation(rams.slice(-olls.length), olls)
      if (Math.abs(ramOllCorr) > 0.5) {
        corrs.push({
          signal1: 'ram_free_mb',
          signal2: 'ollama_response_ms',
          description: ramOllCorr < 0
            ? 'RAM pressure correlates with Ollama slowdown — reduce memory use before inference'
            : 'RAM and Ollama latency moving together (unusual)',
          strength: Math.abs(ramOllCorr),
        })
      }
    }

    return corrs
  }

  // ── Human-readable output ─────────────────────────────────────────────────

  private buildSummary(financial: any, compute: any, balance: number): string {
    const parts: string[] = []

    if (financial.burnRate > 0.01) {
      const days = financial.daysToThreshold(THRESHOLDS.low_compute)
      if (days < Infinity && days < 30) {
        parts.push(`At $${financial.burnRate.toFixed(2)}/day burn rate, low_compute in ${Math.round(days)} days`)
      } else {
        parts.push(`Burn rate $${financial.burnRate.toFixed(2)}/day — stable`)
      }
    } else {
      parts.push(`USDC stable at $${balance.toFixed(2)}`)
    }

    if (compute.hoursUntilSevere !== null) {
      parts.push(`RAM severe pressure predicted in ${Math.round(compute.hoursUntilSevere)}h`)
    }

    return parts.join('. ') + '.'
  }

  private buildRecommendations(financial: any, compute: any): string[] {
    const recs: string[] = []

    const daysToLC = financial.daysToThreshold(THRESHOLDS.low_compute)
    if (daysToLC < 7) {
      recs.push(`Request additional USDC funding — ${Math.round(daysToLC)} days until spend restrictions`)
    }
    if (financial.trajectory === 'depleting_fast') {
      recs.push('Review x402 spend — burn rate is high for current balance')
    }
    if (compute.trend === 'degrading_fast') {
      recs.push('Memory leak suspected — consider restarting agent runtime')
    }
    if (compute.hoursUntilSevere !== null && compute.hoursUntilSevere < 4) {
      recs.push('RAM severe pressure in < 4h — avoid spawning Docker children')
    }

    return recs
  }

  private emptyForecast(): ResourceForecast {
    return {
      currentBalance: 0, dailyBurnRate: 0,
      daysUntilLowCompute: Infinity, daysUntilCritical: Infinity, daysUntilDead: Infinity,
      financialTrajectory: 'stable', financialConfidence: 0,
      currentRamFreeMB: 0, ramTrend: 'stable', predictedSevereInHours: null, computeConfidence: 0,
      correlations: [], summary: 'Insufficient history for forecast.', recommendations: [],
      basedOnNReadings: 0, forecastTimestamp: Date.now(),
    }
  }
}

// ── Math helpers ──────────────────────────────────────────────────────────────

function linearRegression(xs: number[], ys: number[]): { slope: number; intercept: number; r2: number } {
  const n = xs.length
  if (n < 2) return { slope: 0, intercept: ys[0] ?? 0, r2: 0 }

  const sumX  = xs.reduce((a, b) => a + b, 0)
  const sumY  = ys.reduce((a, b) => a + b, 0)
  const sumXY = xs.reduce((a, x, i) => a + x * ys[i], 0)
  const sumX2 = xs.reduce((a, x) => a + x * x, 0)

  const slope     = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX)
  const intercept = (sumY - slope * sumX) / n

  const yMean = sumY / n
  const ssTot = ys.reduce((a, y) => a + (y - yMean) ** 2, 0)
  const ssRes = ys.reduce((a, y, i) => a + (y - (slope * xs[i] + intercept)) ** 2, 0)
  const r2    = ssTot === 0 ? 1 : 1 - ssRes / ssTot

  return { slope, intercept, r2 }
}

function pearsonCorrelation(xs: number[], ys: number[]): number {
  const n  = xs.length
  const mx = xs.reduce((a, b) => a + b, 0) / n
  const my = ys.reduce((a, b) => a + b, 0) / n
  const num = xs.reduce((a, x, i) => a + (x - mx) * (ys[i] - my), 0)
  const dx  = Math.sqrt(xs.reduce((a, x) => a + (x - mx) ** 2, 0))
  const dy  = Math.sqrt(ys.reduce((a, y) => a + (y - my) ** 2, 0))
  return dx * dy === 0 ? 0 : num / (dx * dy)
}
