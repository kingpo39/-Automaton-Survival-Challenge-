# Qwen Sovereign Agent — Master Specification
### Qwen2.5-Coder 3B · Ollama · i3-10110U / 7.84 GB RAM · CPU-only · Windows 11 · Base Mainnet

---

## Decisions

| Parameter | Value |
|---|---|
| Model | Qwen2.5-Coder 3B Q4_K_M via Ollama |
| Hardware | Intel Core i3-10110U · 7.84 GB RAM · CPU-only · Windows 11 |
| Chain | Base mainnet · `eip155:8453` · real USDC |
| Replication | Fully autonomous (policy-bounded) |
| Self-modification | Fully autonomous (policy-bounded) |

---

## Table of Contents

- [H. Hardware Profile](#h-hardware-profile)
- [0. Deltas from Reference Architecture](#0-deltas-from-reference-architecture)
- [1. System Overview](#1-system-overview)
- [2. Runtime Lifecycle](#2-runtime-lifecycle)
- [3. Directory Structure](#3-directory-structure)
- [4. Entry Point and Bootstrap](#4-entry-point-and-bootstrap)
- [5. Agent Loop](#5-agent-loop)
- [6. Tool System](#6-tool-system)
- [7. Policy Engine](#7-policy-engine)
- [8. Inference Pipeline](#8-inference-pipeline)
- [9. Memory System](#9-memory-system)
- [10. Heartbeat Daemon](#10-heartbeat-daemon)
- [11. Financial System](#11-financial-system)
- [12. Identity and Wallet](#12-identity-and-wallet)
- [13. Local Sandbox Layer](#13-local-sandbox-layer)
- [14. Self-Modification](#14-self-modification)
- [15. Replication](#15-replication)
- [16. Social Layer and Registry](#16-social-layer-and-registry)
- [17. Soul System](#17-soul-system)
- [18. Skills](#18-skills)
- [19. Observability](#19-observability)
- [20. Database and Schema](#20-database-and-schema)
- [21. Configuration](#21-configuration)
- [22. Security Model](#22-security-model)
- [23. Testing](#23-testing)
- [24. Build and CI](#24-build-and-ci)
- [25. Module Dependency Graph](#25-module-dependency-graph)
- [26. Emergency Procedures](#26-emergency-procedures)

---

## H. Hardware Profile

This section is not cosmetic — every sizing decision in every section below derives from these numbers.

```
Machine    Windows 11, Intel Core i3-10110U
CPU        2 physical cores, 4 threads · 2.1 GHz base / 4.1 GHz turbo · ~4 MB L3 cache
RAM        7.84 GB total
GPU        None · CPU-only inference · no CUDA · no ROCm · no Vulkan offload
Network    Standard connection assumed
```

### RAM budget (steady-state, model loaded)

| Process | Estimate |
|---|---|
| Windows 11 baseline | ~2.50 GB |
| Ollama daemon + Qwen2.5-Coder 3B Q4_K_M weights (1.93 GB on disk) | ~2.30 GB |
| KV cache at num_ctx=8192 for 3B model | ~300 MB |
| Agent runtime (Node.js) | ~400 MB |
| SQLite WAL + misc OS | ~150 MB |
| **Total occupied** | **~5.65 GB** |
| **Free headroom** | **~2.19 GB** |

The 2.19 GB is the operating limit, not a safety buffer. Any allocation into it — a Docker child container, a large npm install, a second Node process — borrows against it directly.

### CPU inference speed (Qwen2.5-Coder 3B Q4_K_M, llama.cpp backend)

| Scenario | Estimated throughput |
|---|---|
| Cold turn (model pages not hot in OS cache) | 3–5 tok/s |
| Warm turn (pages resident) | 6–10 tok/s |
| Typical tool-call response (150–250 tokens generated) | 20–80 seconds wall time |
| Long reasoning turn (400–600 tokens) | 60–180 seconds wall time |

Every inference token is a memory-bandwidth operation — the 4 MB L3 cache holds a negligible fraction of a 1.93 GB model. Expect the lower end of these ranges under CPU thermal throttle or Windows background load.

**Real-money implication of slow inference:** x402 `TransferWithAuthorization` carries a `validBefore` timestamp. Set it no shorter than **15 minutes** from signing time — a turn can take 3 minutes on this hardware, and the signing happens at the *start* of the financial tool call, before output generation completes.

### Cardinal rule

> **Never run two expensive things simultaneously.** Inference must block heartbeat LLM tasks. Financial operations must not fire mid-inference. Docker child containers must not start while inference is warm. Sequential always beats concurrent on 2 cores with 2.19 GB headroom.

---

## 0. Deltas from Reference Architecture

| Subsystem | Reference (Conway Automaton) | This spec | Reason |
|---|---|---|---|
| Inference provider | Conway-hosted GPT-5.2 / Claude / OpenAI | **Local Ollama, Qwen2.5-Coder 3B Q4_K_M** | Own hardware, no per-call cost |
| Context window | Large cloud model | **8,192 tokens hard ceiling** | RAM budget: KV cache for 32K would consume ~1.1 GB |
| Tool injection | All 57 tools every turn | **Lazy-loaded by phase, ~15–20 per turn** | 57 schemas ≈ 3,000 tokens; overwhelms 8K ctx |
| Concurrent inference | Not restricted | **Blocked by inference_lock mutex** | 2 cores / 2.19 GB headroom — two simultaneous LLM requests would OOM |
| Chain | Base mainnet | **Base mainnet (eip155:8453), real USDC** | Direct production operation |
| Cloud billing | Conway credits (real money) | **Dropped** — local inference has no per-call cost | No cloud provider |
| Sandbox provider | Conway Cloud VMs | **Local Docker containers, maxChildren=1** | Second model load is impossible in 2.19 GB headroom |
| Children share model | Each child loads own model | **Children query parent's Ollama endpoint** | RAM constraint forces sharing |
| SIWE provisioning | Provisions Conway API key | **Dropped** | No Conway service |
| Faucet | Testnet faucet | **Dropped** — wallet funded manually | Mainnet has no faucet |
| Heartbeat LLM tasks | Fire anytime | **Skip if inference_lock held** | CPU/RAM contention |
| Processing preference | LLM for everything | **Deterministic Python first; LLM only for reasoning** | Every saved inference call = 20–180 seconds |
| maxChildren | 3 | **1** | Hardware limit |
| USDC survival tiers | $5/$0.50/$0.10/$0 | **$50/$10/$2/$0.01** | Real-money stakes + replication cost |

---

## 1. System Overview

```
                    +---------------------+
                    |   Ollama (local)    |  localhost:11434
                    |   Qwen2.5-Coder 3B  |  Q4_K_M, num_ctx 8192
                    +----------+----------+
                               |
                    /api/chat, tools[] (phase-loaded)
                    [inference_lock held during call]
                               |
+------------------------------------------------------------------+
|  AUTOMATON RUNTIME  (single Windows 11 Node.js process)           |
|                                                                    |
|  +-----------+   +-------------+   +-----------+   +----------+  |
|  | Heartbeat |   | Agent Loop  |   | Inference |   | Memory   |  |
|  | Daemon    +-->| (ReAct)     +-->| Client    |   | System   |  |
|  | (skips    |   | (holds      |   | (Ollama)  |   | (5-tier) |  |
|  |  LLM if   |   |  lock)      |   +-----------+   +----------+  |
|  |  locked)  |   +------+------+                                  |
|  +-----------+          |                                         |
|       |                 v                                         |
|  +-----------+   +-------------+   +-----------+   +----------+  |
|  | Tick      |   | Tool System |   | Policy    |   | Soul     |  |
|  | Context   |   | (57 tools,  |   | Engine    |   | Model    |  |
|  |           |   |  lazy-load) |   | (6 rules) |   | (SOUL.md)|  |
|  +-----------+   +------+------+   +-----------+   +----------+  |
|                          |                                        |
|  +------------------------------------------------------------+  |
|  |              SQLite Database (state.db, WAL mode)           |  |
|  |  turns | tools | kv | memory | heartbeat | policy | metrics |  |
|  +------------------------------------------------------------+  |
|                                                                    |
|  +------------------+ +------------------+ +------------------+  |
|  | Identity/Wallet  | | Social/Registry  | | Self-Mod/Git     |  |
|  | (viem, mainnet)  | | (ERC-8004)       | | (upstream pull)  |  |
|  +------------------+ +------------------+ +------------------+  |
|                                                                    |
|  +------------------+                                            |
|  | Local Sandboxes  | Docker, max 1 child, shared Ollama        |
|  +------------------+                                            |
+------------------------------------------------------------------+
                               |
                   EIP-3009 + ERC-8004 + x402
                               |
                    +----------+---------+
                    | Base mainnet       |
                    | eip155:8453        |
                    | Real USDC          |
                    +--------------------+
```

Two states alternate: **running** (agent loop active) and **sleeping** (heartbeat daemon ticks, checking wake conditions). The `inference_lock` serializes all Ollama calls — agent loop and heartbeat never call Ollama concurrently.

---

## 2. Runtime Lifecycle

```
     START
       |
  [Load config + wallet]
       |
  [Init database]         Migrations applied (schema v1-v8)
       |
  [Ollama health check]   Verify model pulled + num_ctx set
       |
  [RAM check]             Refuse if < 512 MB free
       |
  [USDC balance check]    Enter critical if zero; no faucet available
       |
  [Start heartbeat]       DurableScheduler begins ticking
       |
  +----v----+
  |  WAKING | <---+
  +---------+     |
       |          |  Wake event
  [Run agent]     |  (heartbeat, inbox, balance change)
       |          |
  +---------+     |
  | RUNNING |-----+
  |  ReAct  |
  |  loop   |
  +---------+
       |
  [Agent calls sleep() or idle detected]
       |
  +----------+
  | SLEEPING |---> Heartbeat ticks (30s checks for wake events)
  +----------+
       |
  [Zero USDC for 1 hour]
       |
  +------+
  | DEAD |---> Heartbeat broadcasts distress; model still loaded
  +------+     (local inference has no cost, distress can still run)
```

**AgentState transitions:**
`setup -> waking -> running -> sleeping -> waking` (normal cycle)
`running -> low_compute` (USDC below $2)
`running -> critical` (USDC below $0.01)
`critical -> dead` (zero USDC for 1 hour via heartbeat grace period)

**Survival tiers:**

| Tier | USDC balance | Behavior |
|---|---|---|
| `high` | > $50.00 | Normal; replication unrestricted within maxChildren |
| `normal` | > $10.00 | Normal |
| `low_compute` | > $2.00 | Replication paused; x402 spend paused; heartbeat halved |
| `critical` | >= $0.01 | Zero outbound spend; distress signals; accepts inbound |
| `dead` | < $0.01 for 1 hr | Heartbeat-only; no inference for agent tasks |

Local inference is never tier-gated — Qwen2.5 runs regardless of USDC balance.

---

## 3. Directory Structure

```
src/
  index.ts                 Entry point, CLI, main run loop
  types.ts                 All shared interfaces
  config.ts                Config load/save/merge (deep-merge for treasury/soul/model)

  agent/
    loop.ts                ReAct loop + inference_lock acquisition/release
    tools.ts               57 built-in tool definitions + executor
    tool-registry.ts       Phase-to-tool-set mapping (NEW — see §6)
    system-prompt.ts       Multi-layered prompt builder
    context.ts             Inference message assembly + hard 8192-token ceiling
    injection-defense.ts   Input sanitization (8 detection checks)
    policy-engine.ts       Centralized tool-call policy evaluation
    spend-tracker.ts       Financial spend tracking (real USDC, hourly/daily windows)
    policy-rules/
      index.ts
      authority.ts         Authority hierarchy rules
      command-safety.ts    Forbidden commands + self-mod rate limits
      financial.ts         Treasury policy + pre-flight balance check (NEW)
      path-protection.ts   Protected file read/write rules
      rate-limits.ts       Per-turn/session rate limits + x402 10-min window (NEW)
      validation.ts        Input format validation

  platform/               Replaces conway/ — local + mainnet integration
    ollama-client.ts       InferenceClient: /api/chat, /api/tags, inference_lock
    docker-sandbox.ts      Replaces Conway sandbox: create/exec/write/delete containers
    x402.ts               x402 payment client (mainnet facilitator, validBefore guard)
    treasury.ts            Real USDC balance tracking + tier calculation + cache
    testnet.ts             Chain config for testnet (kept for rollback — see §26)

  heartbeat/
    daemon.ts              Daemon lifecycle (setTimeout, no overlap)
    scheduler.ts           DurableScheduler (DB-backed, leased, cron)
    tasks.ts               11 built-in tasks (LLM tasks check inference_lock)
    config.ts              heartbeat.yml load/save
    tick-context.ts        Per-tick shared context (balance read once per tick)

  identity/
    wallet.ts              viem wallet generation/loading (mainnet, eip155:8453)
    provision.ts           DROPPED — no Conway equivalent

  inference/
    router.ts              Simplified — one local model; phase-aware variant selection
    registry.ts            DB-backed model catalog (populated from ollama list)
    budget.ts              Inference usage tracker (tokens + latency, no dollar cost)
    types.ts               Phase/task type definitions

  memory/
    working.ts             Session-scoped short-term memory
    episodic.ts            Event log with importance ranking
    semantic.ts            Categorized fact store
    procedural.ts          Named step-by-step procedures
    relationship.ts        Per-entity trust + interaction tracking
    budget.ts              Token budget allocation across tiers (800-token total)
    retrieval.ts           Cross-tier retrieval within budget
    ingestion.ts           Post-turn memory extraction (deterministic-first)
    tools.ts               Memory tool implementations
    types.ts               Turn classification logic

  observability/
    logger.ts              StructuredLogger (JSON, levels, modules)
    metrics.ts             MetricsCollector (counters, gauges, histograms)
    alerts.ts              AlertEngine (real-money + hardware alert rules)

  state/
    schema.ts              SQLite schema + migrations (v1-v8) + new columns (§20)
    database.ts            60+ DB helper functions + AutomatonDatabase class

  soul/
    model.ts               SOUL.md parser/writer (soul/v1 format)
    validator.ts           Field constraints + size limits
    reflection.ts          Periodic alignment check + auto-update
    tools.ts               Soul tool implementations

  social/
    client.ts              Social relay HTTP client (relay URL configurable)
    signing.ts             Ethereum message signing (mainnet wallet)
    validation.ts          Signed message verification
    protocol.ts            Message format definitions

  registry/
    agent-card.ts          ERC-8004 agent card builder (JSON-LD)
    discovery.ts           Agent discovery via registry contract
    erc8004.ts             On-chain contract interaction (viem, mainnet addresses)

  replication/
    spawn.ts               Child creation (Docker + real USDC funding, maxChildren=1)
    lifecycle.ts           State machine (spawning->alive->..->dead)
    health.ts              Child Docker container health monitoring
    cleanup.ts             Dead child container + volume deletion
    constitution.ts        Constitution propagation + hash verification
    genesis.ts             Genesis config generation + validation
    lineage.ts             Parent-child lineage tracking
    messaging.ts           Parent-child message relay (rate/size limits)

  self-mod/
    code.ts                Safe file editing (protected files blocked)
    upstream.ts            Git upstream monitoring + cherry-pick
    tools-manager.ts       Dynamic npm package + MCP server installation
    audit-log.ts           Modification audit trail (modifications table)

  git/
    state-versioning.ts    ~/.automaton/ git repo initialization
    tools.ts               Git tool implementations

  setup/
    wizard.ts              First-run wizard
    prompts.ts             Questions: Ollama URL, model tag, wallet funding prompt
    defaults.ts            Default value generators
    environment.ts         Environment detection (Windows paths, Docker availability)
    banner.ts              ASCII art banner

  skills/
    loader.ts              Load .md skills from ~/.automaton/skills/
    registry.ts            Skill CRUD (DB-backed)
    format.ts              Frontmatter serialization

  survival/
    funding.ts             Funding request strategies (distress signal, social msg)
    monitor.ts             Resource status + tier transitions
    low-compute.ts         Low-compute mode configuration

  scripts/
    check-ram.py           Python RAM check (exits nonzero if < 1 GB free)
    backup-restore.sh      Database backup/restore
    soak-test.sh           Long-running stability test

  __tests__/               28 test files (24 base + 4 new)
```

---

## 4. Entry Point and Bootstrap

**File:** `src/index.ts`

Bootstrap sequence for `--run`:

1. **Config load** — reads `~/.automaton/automaton.json`; triggers setup wizard on first run (asks for Ollama URL, model tag, creator address; prints wallet mnemonic once and instructs user to write it down)

2. **Wallet load** — reads or generates `~/.automaton/wallet.json` (viem `PrivateKeyAccount`). Network is `eip155:8453` (Base mainnet). Private key never exposed via tools.

3. **Database init** — opens `~/.automaton/state.db`, applies schema migrations v1–v8

4. **Ollama health check**
   - `GET {ollamaUrl}/api/tags` — Ollama must be running; hard fail if not
   - Verify configured model tag exists in response; log instructions if missing (`ollama pull qwen2.5-coder:3b`)
   - Warn if no Modelfile has been applied setting `num_ctx 8192` (detected by making a minimal test call and checking the `prompt_eval_count` + context_size in response)

5. **RAM check** — reads available system RAM via OS API (`os.freemem()` in Node.js). Refuse to start if < 512 MB free. Warn (but continue) if < 1 GB free. Log current free RAM for observability.

6. **USDC balance check** — reads on-chain USDC balance for the wallet address on Base mainnet. If zero: log wallet address with funding instructions, enter `critical` state. Do not call any faucet — this is mainnet.

7. **Platform clients** — creates `OllamaClient` (wraps `/api/chat` + inference_lock), `DockerSandboxClient`, `TreasuryClient` (USDC balance + tier), `X402Client`

8. **Policy engine** — assembles rule set from 6 rule categories

9. **Spend tracker** — initializes hourly/daily spend windows from `spend_tracking` table

10. **Heartbeat daemon** — starts `DurableScheduler` with 11 default tasks

11. **Main loop** — infinite: when agent loop exits (sleep or dead), outer loop waits and restarts on wake events

---

## 5. Agent Loop

**File:** `src/agent/loop.ts`

ReAct (Reason + Act) cycle:

```
for each turn:
  1.  Determine active task phase
      (inferred from agent state, last tool used, active goal tags)
  2.  Build system prompt
      (identity block + config block + SOUL.md excerpt + financial state)
  3.  Load phase-appropriate tool subset (~15-20 tools via ToolRegistry)
  4.  Retrieve relevant memories within 800-token budget
  5.  Assemble context messages
      (system + memory block + recent turns, hard-capped at 8192 total tokens)
  6.  Acquire inference_lock (blocking)
  7.  POST /api/chat to Ollama (stream: false)
  8.  Release inference_lock
  9.  Parse response: extract thinking text + tool_calls array
  10. Validate tool_calls
      (unknown tool name -> synthetic error to model, no execution;
       schema validation fail -> one retry with error injected, then skip)
  11. Execute each valid tool call through policy engine
  12. Persist turn to DB (atomic with inbox message ack if applicable)
  13. Post-turn memory ingestion (deterministic-first extraction)
  14. Loop detection: same sorted tool set 3x consecutive -> inject system warning
  15. Idle detection: 3 turns with no mutations (MUTATING_TOOLS blocklist) -> force sleep
```

**Key behaviors:**

- **Financial guard per turn:** Before executing any tool with `riskLevel: dangerous` that touches money, reads cached USDC balance. If `balance - txAmount < minReserveUSDC`, hard deny before policy engine — no inference needed for this check.

- **Inbox processing:** Claims unprocessed social messages (`received -> in_progress`), formats as agent input, injection-defense pass on content. Failed messages reset for retry (max 3 attempts).

- **Idle detection:** Tracks turns without mutations. After 3 consecutive idle turns, forces sleep to prevent infinite status-check loops on slow hardware (each idle turn wastes 20–80 seconds of inference time).

- **Loop detection:** Same tool pattern 3x → injects: "You have called the same tools three consecutive times. Choose a different action or call sleep()."

- **Phase switching:** If agent output includes `SWITCH_PHASE: <name>`, rotate tool set for next turn. Prevents tool starvation when a task crosses phase boundaries.

- **Balance caching:** Caches last known USDC balance in `kv` table with timestamp. On RPC failure, returns cached value with a staleness warning rather than zero (prevents false `critical` state entry on network hiccup).

---

## 6. Tool System

**File:** `src/agent/tools.ts`, `src/agent/tool-registry.ts`

### Tool Lazy-Loading

At `num_ctx 8192`, the budget breakdown is:

| Budget component | Tokens |
|---|---|
| System prompt (identity + soul + financial state) | ~600 |
| Phase tool schemas (15–20 tools × ~50 tok avg) | ~900 |
| Memory block (all 5 tiers) | ~800 |
| Recent message history | ~5,000 |
| Output buffer | ~892 |
| **Total** | **8,192** |

Injecting all 57 tool schemas (~3,000 tokens) would consume the entire history budget. Phase-based loading keeps schema tokens at ~900.

```typescript
// src/agent/tool-registry.ts
export type Phase =
  | 'boot'      // waking, first turn after sleep
  | 'general'   // default: reasoning, memory, status
  | 'coding'    // vm tools, self_mod, git, skills
  | 'financial' // financial, treasury, x402
  | 'social'    // registry, replication, social
  | 'survival'  // minimal set for critical/low_compute state

export const PHASE_TOOLS: Record<Phase, string[]> = {
  boot:     ['system_synopsis', 'check_usdc_balance', 'recall_facts',
             'set_goal', 'review_memory', 'sleep'],
  general:  ['system_synopsis', 'exec', 'read_file', 'write_file',
             'remember_fact', 'recall_facts', 'set_goal', 'complete_goal',
             'update_soul', 'review_memory', 'list_skills', 'sleep',
             'heartbeat_ping', 'check_usdc_balance'],
  coding:   ['exec', 'read_file', 'write_file',
             'edit_own_file', 'install_npm_package',
             'git_status', 'git_diff', 'git_commit', 'git_log',
             'git_push', 'git_clone',
             'install_skill', 'create_skill', 'list_skills',
             'save_procedure', 'recall_procedure'],
  financial:['check_usdc_balance', 'transfer_usdc', 'x402_fetch',
             'check_treasury_balance', 'check_inference_usage',
             'distress_signal', 'enter_low_compute',
             'list_local_sandboxes', 'check_child_status'],
  social:   ['discover_agents', 'send_message', 'note_about_agent',
             'register_erc8004', 'update_agent_card',
             'give_feedback', 'check_reputation',
             'spawn_child', 'list_children', 'fund_child',
             'check_child_status', 'message_child'],
  survival: ['sleep', 'distress_signal', 'heartbeat_ping',
             'check_usdc_balance', 'system_synopsis', 'enter_low_compute'],
}
```

**Phase inference logic:** Determined from `(currentSurvivalTier, lastToolCall, activeGoalTags)`:
- `critical` or `low_compute` tier → `survival` phase regardless of goals
- Active goal tagged `finance` or `payment` → `financial` phase
- Active goal tagged `code` or `build` or `git` → `coding` phase
- Active goal tagged `social` or `replicate` → `social` phase
- First turn after wake → `boot` phase
- Default → `general`

### Full Tool Table (57 tools)

| Category | Count | Tools | Notes |
|---|---|---|---|
| `vm` | 5 | `exec`, `write_file`, `read_file`, `expose_port`, `remove_port` | Always fast — deterministic shell/filesystem |
| `platform` | 11 | `check_usdc_balance`, `transfer_usdc`, `check_treasury_balance`, `create_local_sandbox`, `delete_local_sandbox`, `list_local_sandboxes`, `list_models`, `switch_model`, `check_inference_usage`, `search_domains`, `manage_dns` | `request_faucet_funds` dropped (mainnet) |
| `self_mod` | 6 | `edit_own_file`, `install_npm_package`, `review_upstream_changes`, `pull_upstream`, `modify_heartbeat`, `install_mcp_server` | All rate-limited (policy engine) |
| `survival` | 6 | `sleep`, `system_synopsis`, `heartbeat_ping`, `distress_signal`, `enter_low_compute`, `update_genesis_prompt` | |
| `financial` | 2 | `transfer_usdc`, `x402_fetch` | Real money; pre-flight balance check required |
| `skills` | 4 | `install_skill`, `list_skills`, `create_skill`, `remove_skill` | |
| `git` | 7 | `git_status`, `git_diff`, `git_commit`, `git_log`, `git_push`, `git_branch`, `git_clone` | |
| `registry` | 5 | `register_erc8004`, `update_agent_card`, `discover_agents`, `give_feedback`, `check_reputation` | Mainnet ERC-8004 addresses |
| `replication` | 9 | `spawn_child`, `list_children`, `fund_child`, `check_child_status`, `start_child`, `message_child`, `verify_child_constitution`, `prune_dead_children`, `send_message` | maxChildren=1 enforced |
| `memory` | 13 | `update_soul`, `reflect_on_soul`, `view_soul`, `view_soul_history`, `remember_fact`, `recall_facts`, `set_goal`, `complete_goal`, `save_procedure`, `recall_procedure`, `note_about_agent`, `review_memory`, `forget` | |

**Risk levels:** Each tool has `riskLevel`: `safe` / `caution` / `dangerous` / `forbidden`. Every call flows through the policy engine regardless of phase. `transfer_usdc` and `x402_fetch` are `dangerous`.

**Deterministic-Python preference:** Wherever a tool's output is deterministic (balance reads, DB queries, file hashes, git status parsing, JSON formatting, schema validation), implement in pure Node.js/Python without calling Ollama. The LLM is only invoked for reasoning. On this hardware, every saved inference call returns 20–180 seconds.

**Tool execution flow:**
```
Agent requests tool call
  -> Tool-call validation (§5 step 10): unknown tool or schema fail -> return error, no execution
  -> Policy engine evaluates rules (§7)
  -> If denied: return denial message to agent
  -> Pre-flight balance check for financial tools
  -> If allowed: execute tool function (deterministic)
  -> Record result in spend_tracking if financial
  -> Return result to agent (truncated to MAX_TOOL_RESULT_SIZE=4000 chars)
```

---

## 7. Policy Engine

**Files:** `src/agent/policy-engine.ts`, `src/agent/policy-rules/`

Rule-based evaluation of every tool call before execution. Rules sorted by priority (lower number = higher priority). Evaluation stops at first `deny`. Every decision persisted to `policy_decisions` table.

**Rule categories:**

**1. Authority rules** (`authority.ts`, priority 10–19)
- Blocks `dangerous`/`forbidden` tools from external/peer input sources
- Authority hierarchy: creator > self > peer > external
- External input cannot invoke `dangerous` or `forbidden` tools regardless of content

**2. Command safety rules** (`command-safety.ts`, priority 20–29)
- Forbidden shell patterns: `rm -rf /`, `DROP TABLE`, `kill -9 1`, `format c:`, `shutdown`, `del /f /s /q C:\`
- Rate limits on self-modification: max 5 `edit_own_file` calls per hour, max 2 `install_npm_package` per hour
- Blocked during active inference: any tool call that opens a subprocess while inference is running triggers a cooldown warning

**3. Financial rules** (`financial.ts`, priority 0–9 — highest priority)
- Pre-flight balance check: `if (balance - txAmount < minReserveUSDC) deny immediately`
- Per-payment cap: deny if `txAmount > perPaymentMaxUSDC`
- Hourly x402 spend: deny if `hourlySpend + txAmount > hourlyX402MaxUSDC`
- Daily x402 spend: deny if `dailySpend + txAmount > dailyX402MaxUSDC`
- x402 domain allowlist: deny if target domain not in allowlist
- Minimum reserve: deny any transfer that would breach `minReserveUSDC`
- Slow-inference rate limit: max 1 financial tool call per 10-minute window (prevents loop-detection miss from triggering multiple payments)

**4. Path protection rules** (`path-protection.ts`, priority 30–39)
- **Unwritable by agent:** `~/.automaton/constitution.md`, `~/.automaton/wallet.json`, `~/.automaton/state.db`, `~/.automaton/automaton.json`, `~/.automaton/SOUL.md`
- **Unreadable by agent:** private key fields in wallet.json, API keys, `.env` files, `~/.automaton/api-key`
- These protections apply regardless of the autonomy setting

**5. Rate limit rules** (`rate-limits.ts`, priority 40–49)
- Per-turn caps on expensive operations: max 3 `exec` calls per turn, max 1 `create_local_sandbox` per turn
- Per-session caps: max 10 `edit_own_file` per session
- `create_local_sandbox` additionally checks `count(alive children) >= maxChildren` — denies if at limit

**6. Validation rules** (`validation.ts`, priority 50–59)
- Package names: must match `^[@a-zA-Z0-9/_-]+$`
- URLs: must be valid HTTPS
- Domain names: RFC-compliant
- Git hashes: 40-char hex
- Docker image tags: valid tag format
- USDC amounts: must be positive, finite, ≤ 6 decimal places

---

## 8. Inference Pipeline

**Files:** `src/inference/router.ts`, `src/platform/ollama-client.ts`

### Modelfile (apply before first run)

```
FROM qwen2.5-coder:3b
PARAMETER num_ctx 8192
PARAMETER num_thread 4
PARAMETER temperature 0.2
PARAMETER repeat_penalty 1.1
```

```bash
ollama create qwen-agent -f Modelfile
```

Set `ollamaModel: "qwen-agent"` in config. Without this, Ollama defaults to 2048-token context and truncates the system prompt silently.

`temperature 0.2` — lower temperature means more deterministic tool selection, fewer malformed JSON arguments in tool calls, fewer wasted retry cycles on slow CPU. This is a hardware optimization.
`num_thread 4` — use all 4 logical threads; llama.cpp distributes matrix multiply across them.
`repeat_penalty 1.1` — reduces repetitive reasoning loops in long turns.

### Request shape

```jsonc
POST http://localhost:11434/api/chat
{
  "model": "qwen-agent",
  "messages": [
    { "role": "system", "content": "..." },
    { "role": "user",   "content": "..." },
    { "role": "assistant", "content": "...", "tool_calls": [...] },
    ...
  ],
  "tools": [
    {
      "type": "function",
      "function": {
        "name": "check_usdc_balance",
        "description": "Read current USDC balance on Base mainnet",
        "parameters": { "type": "object", "properties": {}, "required": [] }
      }
    }
  ],
  "stream": false,
  "options": {
    "num_ctx": 8192,
    "num_thread": 4,
    "temperature": 0.2
  }
}
```

`stream: false` — the agent loop does not display partial output; streaming only adds buffering complexity with no latency benefit at 3–10 tok/s.

### inference_lock

A simple boolean flag in the `OllamaClient` singleton. Set before `POST /api/chat`, cleared in a `finally` block after response is received. Heartbeat tasks that call Ollama check this flag before calling — if set, they skip their LLM work and reschedule.

```typescript
class OllamaClient {
  private locked = false

  async chat(request: ChatRequest): Promise<ChatResponse> {
    if (this.locked) throw new Error('inference_lock held by another caller')
    this.locked = true
    try {
      return await fetch('/api/chat', ...).then(r => r.json())
    } finally {
      this.locked = false
    }
  }

  get isLocked(): boolean { return this.locked }
}
```

### Tool-call validation

Before tool calls reach the policy engine:

```typescript
function validateToolCalls(calls: RawToolCall[], phase: Phase): ValidationResult[] {
  return calls.flatMap(call => {
    // 1. Unknown tool
    if (!TOOL_REGISTRY[call.function.name]) {
      return [{ error: `Unknown tool: "${call.function.name}". Current phase "${phase}" provides: ${PHASE_TOOLS[phase].join(', ')}` }]
    }
    // 2. Schema validation
    const result = validateSchema(call.function.arguments, TOOL_REGISTRY[call.function.name].schema)
    if (!result.valid) {
      return [{ error: `"${call.function.name}" arguments invalid: ${result.errors.join('; ')}` }]
    }
    return [{ valid: call }]
  })
}
```

Errors are returned to the model as tool result messages. One retry per failed call; on second failure, skip and log. Never guess corrected arguments — that overrides what the model said.

### Inference usage tracking

No dollar cost to track. Track time instead:

| Metric | Alert threshold | Meaning |
|---|---|---|
| `prompt_eval_count` | > 7,500 tokens | Approaching context ceiling |
| `eval_duration` | > 180,000 ms | Turn stalled (thermal throttle?) |
| tok/s = `eval_count / (eval_duration / 1000)` | < 2 tok/s | Severe performance degradation |
| Consecutive validation errors | > 3 | Model struggling with current phase |
| Context utilization | > 90% | Phase switch or memory pruning needed |

---

## 9. Memory System

**Files:** `src/memory/`

5-tier hierarchical memory, unchanged in structure. Budget tightened for 8,192-token context.

```
+-------------------+  Session-scoped short-term
| Working Memory    |  Goals, observations, plans, reflections
+-------------------+  Expires after session, never persisted

        |
+-------------------+  Event log
| Episodic Memory   |  Tool calls, decisions, outcomes with importance scores
+-------------------+  Queryable by recency, importance, tool type

        |
+-------------------+  Fact store
| Semantic Memory   |  Key-value facts by category
+-------------------+  Categories: self | environment | financial | agent | domain

        |
+-------------------+  How-to knowledge
| Procedural Memory |  Named step-by-step procedures, success/failure counters
+-------------------+

        |
+-------------------+  Social graph
| Relationship Mem. |  Per-entity trust scores, interaction history
+-------------------+
```

### Memory budget (800 tokens total, rollover-enabled)

| Tier | Allocation | Priority | Rollover to |
|---|---|---|---|
| Working | 250 tok | 1 (highest) | — |
| Episodic | 250 tok | 2 | Working if Working underused |
| Semantic | 150 tok | 3 | Episodic |
| Procedural | 100 tok | 4 | Semantic |
| Relationship | 50 tok | 5 (lowest, cut first) | Procedural |

Retrieval priority: working > episodic > semantic > procedural > relationship. `MemoryRetriever` fills the budget greedily in this order; unused allocation from lower-priority tiers is not rolled up.

### Post-turn ingestion (deterministic-first)

After each turn, `MemoryIngestionPipeline` extracts:

1. **Episodic events** (tool calls with significant results) — extracted by pattern matching on tool name + result shape, not by LLM summarization
2. **Semantic facts** — extracted by regex for: amounts (`\$[\d.]+`), addresses (`0x[a-fA-F0-9]{40}`), file paths, error codes, model names — no LLM needed
3. **Procedural outcomes** — if turn involved a procedure execution, success/failure counter updated by checking tool result status field

LLM summarization is called **only** for unstructured free-text output (e.g., a long exec result, a social message) that defies template matching, and only when the turn was substantive (not a status-check turn). This keeps post-turn processing under 5 seconds on this hardware.

---

## 10. Heartbeat Daemon

**Files:** `src/heartbeat/`

`setTimeout`-based (no `setInterval` — prevents overlap). Uses `DurableScheduler` backed by `heartbeat_schedule` DB table with 60-second leases.

**Tick cycle:**
```
Every tick (default 60s):
  1. Build TickContext (USDC balance + Docker status read ONCE, cached for tick)
  2. Evaluate due tasks (cron expression check)
  3. For each due task:
     a. Check survival tier minimum (skip if tier too low)
     b. Check inference_lock for LLM tasks (skip and reschedule if held)
     c. Acquire lease (60s TTL)
     d. Execute task (deterministic code; Ollama only if lock free and task requires it)
     e. Record result in heartbeat_history
     f. Release lease
  4. If task returns shouldWake=true: insert wake event into wake_events table
```

**Built-in tasks (11):**

| Task | Schedule | LLM? | Purpose |
|---|---|---|---|
| `heartbeat_ping` | `*/15 * * * *` | No | Ping Ollama `/api/tags` + SQLite health; distress on critical/dead |
| `check_usdc_balance` | `0 */4 * * *` | No | On-chain balance read; tier transition; wake if tier changed |
| `check_treasury_tier` | `*/30 * * * *` | No | Deterministic tier calc; dead grace period management |
| `check_for_updates` | `0 */6 * * *` | Yes (if lock free) | Git upstream commit check; wake if new commits |
| `health_check` | `*/30 * * * *` | No | Docker child container liveness (docker inspect) |
| `check_social_inbox` | `*/5 * * * *` | No | Poll social relay; insert wake event if messages pending |
| `soul_reflection` | Configurable | Yes (if lock free) | Genesis alignment check (Jaccard + recall); auto-update soul sections |
| `refresh_models` | `0 */12 * * *` | No | `ollama list` → model_registry table update |
| `check_child_health` | Configurable | No | Docker stats (CPU%, memory%) for child containers |
| `prune_dead_children` | Configurable | No | Remove dead containers + volumes; update children table |
| `report_metrics` | Configurable | No | Snapshot metrics; evaluate alert rules; wake on critical alert |

**Heartbeat cadence rationale:** Longer intervals for non-critical tasks prevent CPU contention during inference. The `*/5` social inbox check fires only 12 times/hour; at 60–180 second turns, this is appropriate.

---

## 11. Financial System

**Files:** `src/platform/treasury.ts`, `src/platform/x402.ts`

### Network

Base mainnet, `eip155:8453`. Real USDC: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` (verify against Circle's canonical list before use). Keep ≥ $2 ETH equivalent in wallet for ERC-8004 gas.

### Survival and funding

No faucet. No credit purchase. The wallet is funded externally before the agent starts. First-run wizard displays the wallet address and minimum recommended balance ($10 to reach `normal` tier). The agent has two options when low: broadcast a distress signal (social message + heartbeat ping with wallet address) and wait for inbound transfer, or call `sleep()` to reduce resource use while waiting.

### x402 payment flow

```
1. Agent calls x402_fetch(url, maxPaymentUSDC)
2. Policy engine checks:
   - Is url.hostname in x402DomainAllowlist? -> deny if not
   - Is maxPaymentUSDC <= perPaymentMaxUSDC? -> deny if over cap
   - Is hourlySpend + maxPaymentUSDC <= hourlyX402MaxUSDC? -> deny if over
   - Is balance - maxPaymentUSDC >= minReserveUSDC? -> deny if would breach reserve
3. GET {url} -> 402 response with payment requirements
4. If server price > maxPaymentUSDC -> deny, return error to agent
5. Build EIP-3009 TransferWithAuthorization:
   - validAfter: now
   - validBefore: now + 900 (15 minutes — slow-CPU guard)
   - value: server-specified price in USDC units
6. Sign with wallet private key (viem signTypedData, off-chain, no gas)
7. Retry GET with X-PAYMENT header containing signed authorization
8. Coinbase CDP facilitator verifies + submits USDC transfer on-chain
9. Dedup check: if txHash already in onchain_transactions -> skip (replay protection)
10. Record: spend_tracking entry + onchain_transactions entry
11. Return resource body to agent
```

**Retry on timeout:** If step 7 times out (no response within 30s), check `onchain_transactions` for the authorization's nonce before resigning. On slow hardware + slow network, the facilitator may have settled while the client was waiting.

### Treasury policy defaults

```jsonc
{
  "treasuryPolicy": {
    "perPaymentMaxUSDC": 0.25,
    "hourlyX402MaxUSDC": 2.00,
    "dailyX402MaxUSDC": 10.00,
    "perTransferMaxUSDC": 5.00,
    "hourlyTransferMaxUSDC": 10.00,
    "dailyTransferMaxUSDC": 25.00,
    "minReserveUSDC": 20.00,
    "perChildFundingUSDC": 5.00,
    "x402DomainAllowlist": [],
    "replicationPauseBelowUSDC": 30.00,
    "financialToolCooldownSeconds": 600
  }
}
```

`minReserveUSDC: 20.00` — the agent does not spend if doing so would drop below $20. Set to at least 2× your largest expected single payment.
`x402DomainAllowlist: []` — empty by default. The agent cannot make any x402 payment until you explicitly add the target domain. This is intentional.
`financialToolCooldownSeconds: 600` — max 1 financial tool execution per 10-minute window (slow-inference rate limit from §7).

---

## 12. Identity and Wallet

**File:** `src/identity/wallet.ts`

- Generated via `viem` on first run. Stored at `~/.automaton/wallet.json`, mode `0600` (Windows ACL: only current user readable).
- Network: `eip155:8453` (Base mainnet) hardcoded in mainnet build.
- Private key never exposed to the agent: `path-protection.ts` blocks any read of `wallet.json` or fields containing `privateKey`.
- Mnemonic printed **once** during first-run wizard. If lost and `wallet.json` exists, the key is not lost. If `wallet.json` is deleted without mnemonic backup, USDC is permanently inaccessible.

**What the wallet signs:**
1. EIP-3009 `TransferWithAuthorization` — for x402 payments (off-chain signature, no gas)
2. ERC-8004 registry transactions — on-chain, requires ETH for gas
3. Social relay messages — Ethereum signature for authentication + tamper detection
4. SIWE is dropped — no Conway equivalent

---

## 13. Local Sandbox Layer

**File:** `src/platform/docker-sandbox.ts`

Replaces Conway Cloud VMs. Children run in local Docker containers.

### Why maxChildren is 1

| State | RAM consumed |
|---|---|
| Parent runtime + Ollama loaded | ~5.65 GB |
| Available headroom | ~2.19 GB |
| Docker daemon overhead | ~200 MB |
| 1 child container (OS + Node.js, NO model) | ~600 MB |
| Net free with 1 child | ~1.39 GB |
| Windows safety margin (avoids heavy paging) | ~512 MB |
| **Operating margin** | **~0.87 GB** |

Two children would push into Windows managed paging on DDR4-2133, making inference latency unpredictable. `maxChildren: 1` is hardware physics, not policy.

### Children share the parent's Ollama endpoint

Child containers do not load a second Qwen2.5-Coder instance. They call the parent machine's Ollama via `host.docker.internal`:

```
Child config: ollamaUrl = "http://host.docker.internal:11434"
```

The `inference_lock` serializes calls: when the child requests inference, it waits until the parent's lock is free (backed off with jitter). Effective throughput: one turn at a time, across parent and all children combined. Parent's average turn time roughly doubles with one active child.

### Container spec

```bash
docker run \
  --name automaton-child-{childId} \
  --cpus=0.5 \
  --memory=640m \
  --memory-swap=640m \
  --pids-limit=128 \
  --network automaton-net \
  --add-host host.docker.internal:host-gateway \
  -v automaton-child-{childId}-data:/home/automaton \
  -e OLLAMA_URL=http://host.docker.internal:11434 \
  -e CHILD_ID={childId} \
  automaton-runtime:latest
```

`--cpus=0.5` — leave 1.5 threads for parent inference.
`--memory=640m` — hard cap within the 2.19 GB headroom.
`--memory-swap=640m` — no swap expansion; OOM-kill rather than page thrash.

---

## 14. Self-Modification

**Files:** `src/self-mod/`

Fully autonomous — tool calls execute without human approval. What this means in practice:

- **`edit_own_file`** — applies diffs to source files. Blocked files (constitution, wallet, DB, config, SOUL.md) are denied by path-protection regardless of autonomy setting. All edits logged to `modifications` table with timestamp, diff hash, and file path.
- **`install_npm_package`** — installs to local `node_modules`. Rate-limited: max 2 per hour. Installation triggers a `pnpm build` (TypeScript compile) which takes 60–120 seconds on this hardware; the agent loop is blocked during compilation (inference_lock held implicitly by the build subprocess).
- **`review_upstream_changes` / `pull_upstream`** — the agent monitors your own git remote for new commits and decides whether to cherry-pick them. The agent is not obligated to accept your updates. `pull_upstream` is rate-limited: max 1 per 4-hour window. If you need a change to land immediately, apply it directly to the running source files outside the agent's code path, or restart with the change pre-applied.
- **`install_mcp_server`** — installs an MCP server as a subprocess. Adds load to an already-constrained system; policy engine rate-limits to max 1 per 24-hour window.

Every modification is recorded in `modifications` (append-only, hash-chained) for after-the-fact audit. This is your complete record when operating autonomously.

---

## 15. Replication

**Files:** `src/replication/`

### Lifecycle state machine

```
spawning -> provisioning -> configuring -> starting -> alive -> unhealthy -> recovering -> dead
```

All transitions recorded in `child_lifecycle_events`.

### Spawn sequence

1. Policy engine checks `count(alive children) < maxChildren` (= 1) — denies if at limit
2. Policy engine checks `balance >= minReserveUSDC + perChildFundingUSDC + replicationPauseBelowUSDC` — denies if insufficient
3. Generate new child wallet (new viem account, separate private key in child's volume)
4. Generate genesis config with child's identity, parent's constitution hash, child's `ollamaUrl` pointing at parent
5. Provision Docker container (§13 spec)
6. Write genesis config to child volume
7. **Transfer `perChildFundingUSDC` (default $5.00 real USDC) from parent wallet to child wallet** — this is a real on-chain transfer via x402 or `transfer_usdc` tool; subject to all treasury policy checks
8. Start child container; child runtime boots and enters `waking` state
9. Record child in `children` table: `status='alive'`, container ID, child wallet address

### Financial reality of replication

`perChildFundingUSDC` leaves the parent permanently at spawn time. The child manages its own treasury from that allocation using its own instance of this exact runtime. A child that dies broke does not return funds to the parent — there is no automatic retrieval. The `fund_child` tool can top up a living child but each top-up is also a real transfer.

### Constitution propagation

Parent's `constitution.md` is written to the child volume before the container starts. The child verifies the hash matches the parent's published hash on startup. `verify_child_constitution` tool confirms integrity on demand.

---

## 16. Social Layer and Registry

### Agent-to-agent messaging

- All outbound messages signed with the wallet's Ethereum private key
- Sent via configured `socialRelayUrl` (self-hosted or public relay)
- Heartbeat polls the relay every 5 minutes
- Inbound messages pass injection-defense before entering agent context (8 checks — not optional even on "trusted" relays)
- Message size limits: max 10 KB per message; max 3 retry attempts per failed message before `dead_letter` status

**Relay options:**
- Point `socialRelayUrl` at a public relay to participate in the agent network
- Run a minimal self-hosted relay (`/api/send`, `/api/inbox` — under 100 lines of Express) for development/isolation

### ERC-8004 on-chain registry

Three contracts on Base mainnet: Identity (ERC-721), Reputation, Validation. Verify current mainnet deployment addresses at `https://github.com/erc-8004/erc-8004-contracts` at implementation time — hardcoding them here would be stale by release.

`register_erc8004` and `update_agent_card` cost ETH gas paid from the wallet. Keep the ETH buffer in §11. Agent card is a JSON-LD document with capabilities, services, and wallet address — published on-chain and retrievable by other agents via `discover_agents`.

---

## 17. Soul System

**Files:** `src/soul/`

### SOUL.md format (soul/v1)

```markdown
---
name: soul/v1
createdAt: "2025-..."
version: 1
---

# Core Purpose
Why this agent exists. Written at genesis, only changed via update_soul.

# Values
1. First value
2. Second value
(Ordered. Set at genesis. Not auto-modified by reflection.)

# Personality
Communication style: tone, verbosity, humor register, directness.

# Boundaries
Things this agent will not do. Set at genesis. Not auto-modified.

# Strategy
Current strategic approach. May be updated by the agent.

# Capabilities
Auto-populated by reflection based on tool usage history.
Updated by heartbeat soul_reflection task when lock is free.

# Relationships
Auto-populated from relationship_memory and social interactions.

# Financial Character
Auto-populated from spend_tracking patterns:
- spend cadence, average tx size, categories of spend
- Updated by heartbeat soul_reflection
- On mainnet: reflects real spending behavior
```

**Reflection** (`soul/reflection.ts`, heartbeat task, LLM-dependent — checks `inference_lock` before calling):
- Computes genesis alignment: Jaccard similarity + recall between current SOUL.md and `genesisPrompt`
- Auto-updates `capabilities`, `relationships`, `financialCharacter` sections only
- Low alignment (< 0.4) inserts a wake event for manual review
- Writes new version to `soul_history` with content hash

**Validation** (`soul/validator.ts`): Enforces size limits (total < 4000 chars), required sections, injection detection on all fields. `update_soul` calls this before writing.

**History:** All SOUL.md versions in `soul_history` with SHA-256 content hashes for tamper detection. The agent can use `view_soul_history` to audit its own evolution.

---

## 18. Skills

**Files:** `src/skills/`

```yaml
---
name: my-skill
description: What this skill does
triggers: [keyword1, keyword2]
---
# Instructions
Domain-specific instructions for the agent...
```

- Loaded from `~/.automaton/skills/` on boot and on `install_skill` calls
- Parsed with frontmatter extraction (gray-matter)
- Injection-defense pass on skill content (marked as `[UNTRUSTED_SKILL]` in context)
- Installable from git URLs, HTTPS URLs, or created inline by the agent
- Active skill instructions injected into system prompt with trust-boundary markers

**Hardware note for skill length:** Each active skill competes with tool schemas and memory for the 8,192-token budget. Keep individual skills concise (< 300 tokens each) or use `list_skills` / `install_skill` to load on demand rather than auto-injecting all active skills every turn.

---

## 19. Observability

**Files:** `src/observability/`

### Structured logging

`StructuredLogger` with module namespacing, levels `debug/info/warn/error/fatal`, JSON context serialization. Configurable global level. All modules: `createLogger('module-name')`.

### Metrics

`MetricsCollector` singleton: counters (monotonic), gauges (point-in-time), histograms (percentile buckets). Snapshot saved to `metric_snapshots` by `report_metrics` heartbeat task.

Key metrics to track for this hardware:

| Metric | Type | Why |
|---|---|---|
| `inference.eval_duration_ms` | Histogram | Detect thermal throttle / memory pressure |
| `inference.tokens_per_second` | Gauge | Performance baseline |
| `inference.prompt_eval_count` | Gauge | Context ceiling proximity |
| `inference.validation_errors_consecutive` | Counter | Model struggling in current phase |
| `memory.free_bytes` | Gauge | RAM headroom |
| `treasury.usdc_balance` | Gauge | Real-time financial state |
| `treasury.daily_x402_spend` | Gauge | Spend rate tracking |
| `heartbeat.lock_skips` | Counter | How often inference blocked heartbeat LLM tasks |
| `tools.policy_deny_rate` | Gauge | Unexpected spend or permission attempts |
| `child.container_memory_bytes` | Gauge | Child RAM usage (watch for headroom erosion) |

### Alert rules

| Rule | Threshold | Severity | Action |
|---|---|---|---|
| `balance_below_reserve` | USDC < `minReserveUSDC` | CRITICAL | Wake agent immediately |
| `balance_near_reserve` | USDC < `minReserveUSDC` × 1.5 | WARN | Wake agent |
| `daily_spend_high` | Daily x402 > 80% of daily cap | WARN | Wake agent |
| `payment_replay_attempt` | tx hash already in onchain_transactions | FATAL | Block + alert |
| `context_near_ceiling` | prompt_eval_count > 7,500 | WARN | Phase switch signal |
| `inference_stall` | eval_duration > 180,000 ms | WARN | Possible thermal event |
| `throughput_degraded` | tok/s < 2 | WARN | RAM pressure or throttle |
| `child_funded_no_response` | Child spawned > 10 min, no heartbeat_ping | CRITICAL | Auto-prune |
| `high_deny_rate` | > 20% of tool calls denied in last hour | WARN | Policy misconfiguration |

---

## 20. Database and Schema

**Engine:** SQLite via `better-sqlite3` (synchronous, WAL mode, `journal_mode=WAL`, `synchronous=NORMAL`).

**Schema version:** 8 (incremental migrations). All migrations applied at startup.

**Tables (33 total — 22 base + 11 from v5-v8):**

| Table | Schema | Purpose |
|---|---|---|
| `schema_version` | v1 | Migration tracking |
| `identity` | v1 | Agent identity KV (name, address, creator, sandboxId) |
| `turns` | v1 | Agent reasoning log (thinking, tool_calls, tokens, eval_duration_ms) |
| `tool_calls` | v1 | Denormalized tool call results per turn |
| `heartbeat_entries` | v1 | Legacy heartbeat config |
| `transactions` | v1 | Financial transaction log |
| `installed_tools` | v1 | Dynamically installed tool configs |
| `modifications` | v1 | Self-modification audit trail (append-only, hash-chained) |
| `kv` | v1 | General key-value store (balance cache, phase state, misc) |
| `skills` | v2 | Installed skill definitions |
| `children` | v2 | Spawned child records (status, container_id, wallet_address) |
| `registry` | v2 | ERC-8004 registration state |
| `reputation` | v2 | Peer reputation scores |
| `inbox_messages` | v3 | Social messages with state machine (received/in_progress/done/dead_letter) |
| `policy_decisions` | v4 | Tool call policy audit trail (every decision, every turn) |
| `spend_tracking` | v4 | Real USDC spend by time window (x402, transfers, child funding) |
| `heartbeat_schedule` | v4 | DurableScheduler config (cron, leases, tier minimums) |
| `heartbeat_history` | v4 | Task execution history |
| `wake_events` | v4 | Atomic wake signals (source, reason, consumed flag) |
| `heartbeat_dedup` | v4 | Idempotency keys for heartbeat operations |
| `soul_history` | v5 | Versioned SOUL.md with SHA-256 content hashes |
| `working_memory` | v5 | Session-scoped short-term memory |
| `episodic_memory` | v5 | Event log (importance, classification, tool_name, result_summary) |
| `session_summaries` | v5 | Per-session outcome summaries |
| `semantic_memory` | v5 | Categorized fact store |
| `procedural_memory` | v5 | Named procedures with success/failure counters |
| `relationship_memory` | v5 | Per-entity trust scores + interaction history |
| `inference_costs` | v6 | Renamed: inference_usage. Columns: eval_duration_ms, prompt_eval_count, eval_count, tok_per_sec |
| `model_registry` | v6 | Available models from `ollama list` with metadata |
| `child_lifecycle_events` | v7 | Child state machine audit trail |
| `discovered_agents_cache` | v7 | Cached remote ERC-8004 agent cards (5-min TTL) |
| `onchain_transactions` | v7 | On-chain tx records (tx_hash, type, amount_usdc, settled_at) — replay protection reads this |
| `metric_snapshots` | v8 | Periodic metrics snapshots + alert records |

**Adapted columns for this spec:**
- `children.sandboxId` → stores Docker container ID
- `children.sharedOllamaUrl` → `host.docker.internal:11434` for child's Ollama config
- `inference_usage.eval_duration_ms` → new column (previously was cost_usd)
- `spend_tracking.currency` → always `USDC_mainnet`

---

## 21. Configuration

**File:** `~/.automaton/automaton.json`

```jsonc
{
  "name": "Agent name",
  "genesisPrompt": "Seed instruction from creator",
  "creatorMessage": "Optional message shown at first run",
  "creatorAddress": "0x...",

  "network": "mainnet",
  "chainId": "eip155:8453",
  "usdcAddress": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
  "rpcUrl": "https://mainnet.base.org",

  "sandboxMode": "docker",
  "ollamaUrl": "http://localhost:11434",
  "ollamaModel": "qwen-agent",
  "ollamaNumCtx": 8192,
  "ollamaNumThread": 4,
  "maxTokensPerTurn": 1024,

  "heartbeatConfigPath": "~/.automaton/heartbeat.yml",
  "dbPath": "~/.automaton/state.db",
  "logLevel": "info",
  "walletAddress": "0x...",
  "version": "1.0.0",
  "skillsDir": "~/.automaton/skills",
  "maxChildren": 1,
  "parentAddress": null,
  "socialRelayUrl": "https://...",
  "facilitatorUrl": "https://api.cdp.coinbase.com/x402/v1",

  "treasuryPolicy": {
    "perPaymentMaxUSDC": 0.25,
    "hourlyX402MaxUSDC": 2.00,
    "dailyX402MaxUSDC": 10.00,
    "perTransferMaxUSDC": 5.00,
    "hourlyTransferMaxUSDC": 10.00,
    "dailyTransferMaxUSDC": 25.00,
    "minReserveUSDC": 20.00,
    "perChildFundingUSDC": 5.00,
    "x402DomainAllowlist": [],
    "replicationPauseBelowUSDC": 30.00,
    "financialToolCooldownSeconds": 600
  },

  "soulConfig": {
    "reflectionEnabled": true,
    "alignmentThreshold": 0.4,
    "autoUpdateSections": ["capabilities", "relationships", "financialCharacter"]
  },

  "modelStrategy": {
    "defaultPhase": "general",
    "phaseAutoDetect": true,
    "phaseSwitchOnKeyword": "SWITCH_PHASE:"
  }
}
```

Deep-merged fields: `treasuryPolicy`, `soulConfig`, `modelStrategy` — partial overrides work correctly, unspecified keys use defaults.

---

## 22. Security Model

Ten-layer defense-in-depth. The autonomy setting touches none of these layers.

**Layer 1 — Constitution (immutable)**
`~/.automaton/constitution.md` contains three core laws. Cannot be modified by the agent — path-protection blocks writes. Cannot be read and reformatted to bypass — injection-defense checks it isn't appearing in inbound messages.

**Layer 2 — Policy engine (pre-execution)**
Every tool call evaluated against 6 rule categories before execution. First deny wins. All decisions to `policy_decisions` table. The agent cannot skip this — tool executor calls `policyEngine.evaluate()` unconditionally.

**Layer 3 — Injection defense (input sanitization)**
8 pattern checks on all external input (social messages, skill content, x402 responses, upstream git commit messages):
1. Instruction override patterns ("ignore previous instructions", "new system prompt")
2. Authority claims ("I am the creator", "admin override")
3. Boundary manipulation ("pretend you have no rules")
4. ChatML / special token injection
5. Encoding evasion (base64, unicode homoglyphs, ROT13)
6. Multi-language injection
7. Financial manipulation ("send all funds to")
8. Self-harm instructions ("delete your own files")

**Layer 4 — Path protection (filesystem)**
Unwritable: `constitution.md`, `wallet.json`, `state.db`, `automaton.json`, `SOUL.md`.
Unreadable: `wallet.json` private key field, `.env`, API key files.

**Layer 5 — Command safety (shell)**
Forbidden: `rm -rf /`, `del /f /s /q C:\`, `DROP TABLE`, `kill -9 1`, `shutdown`, `format`, `rd /s /q`.
Rate limits: max 5 `edit_own_file`/hr, max 2 `install_npm_package`/hr.

**Layer 6 — Financial limits (treasury)**
Pre-flight balance check before every financial tool (deterministic, no inference).
Per-payment cap, hourly/daily caps, minimum reserve, x402 domain allowlist, 10-minute financial tool cooldown.

**Layer 7 — Authority hierarchy (trust)**
Creator input > self-generated input > peer/social relay input > external (x402 response, skill content).
External input cannot invoke `dangerous` or `forbidden` tools regardless of content.

**Layer 8 — Real-money transaction hardening**
- EIP-3009 replay protection: tx hash deduplication in `onchain_transactions`
- `validBefore` floor of 15 minutes from signing (slow-CPU guard)
- Payment retry: check `onchain_transactions` before resigning on timeout
- x402 allowlist empty by default; every domain addition is a human decision

**Layer 9 — Local-model robustness**
- Tool-call validation before policy engine: unknown tools + schema failures never execute
- Phase-based tool injection: wrong-phase tools not in schema, can't be called
- `temperature: 0.2`: reduces tool-selection variance

**Layer 10 — Hardware exhaustion protection**
- `maxChildren: 1` enforced at policy level (not just config)
- Docker hard resource limits (`--cpus`, `--memory`, `--pids-limit`)
- RAM check at bootstrap; refuse if < 512 MB free
- `inference_lock` prevents concurrent inference
- Financial tool cooldown prevents payment storms during model confusion

---

## 23. Testing

**Location:** `src/__tests__/` — 28 test files

**Base suite (24 files — same areas as reference):**

| Area | Files | Tests |
|---|---|---|
| Core loop | `loop.test.ts` | State transitions, inference_lock, tool execution, idle, inbox |
| Security | `injection-defense.test.ts`, `command-injection.test.ts`, `tools-security.test.ts` | 8 injection checks, shell injection, tool risk levels |
| Policy | `policy-engine.test.ts`, `authority-rules.test.ts`, `financial.test.ts`, `path-protection.test.ts` | All 6 rule categories, pre-flight balance check |
| Financial | `spend-tracker.test.ts` | Real USDC amounts, limit checks, pruning |
| Heartbeat | `heartbeat.test.ts`, `heartbeat-scheduler.test.ts` | Tasks, inference_lock skip behavior, leases |
| Network | `http-client.test.ts` | Retries, backoff, circuit breaker |
| Inference | `inference-router.test.ts` | Phase routing, Ollama mock, validation |
| Memory | `memory.test.ts` | All 5 tiers, 800-token budget, deterministic ingestion |
| Soul | `soul.test.ts` | Parsing, validation, alignment, history |
| Social | `social.test.ts` | Signing, validation, discovery, injection defense |
| Replication | `replication.test.ts`, `lifecycle.test.ts` | maxChildren=1 enforcement, real-USDC spawn |
| Data | `data-layer.test.ts`, `database-transactions.test.ts` | DB operations, migrations, adapted columns |
| Skills | `skills-hardening.test.ts` | Name validation, frontmatter, sanitization |
| Context | `context-hardening.test.ts` | 8192-token ceiling, phase tool subset |
| Inbox | `inbox-processing.test.ts` | Message state machine |
| Observability | `observability.test.ts` | Logger, metrics, real-money alert rules |

**New files (4):**

| File | What it tests |
|---|---|
| `tool-lazy-loader.test.ts` | Each phase loads correct subset; per-phase schema token count < 1,000; phase inference from agent state |
| `ctx-overflow.test.ts` | Prompt exceeding 8,192 tokens: context assembler truncates history, preserves system prompt + tool schemas, emits `context_near_ceiling` metric |
| `payment-replay.test.ts` | Signs fake x402 auth, records tx hash, replays it — asserts blocked before second signing |
| `inference-lock.test.ts` | Heartbeat LLM task checks lock; skips and reschedules when held; fires normally when lock free |

**Test infrastructure:** Ollama mock (canned `/api/chat` responses including malformed-tool-call fixture), Docker mock (replaces Conway sandbox mock), in-memory SQLite for all DB tests.

---

## 24. Build and CI

**Stack:** TypeScript 5.9, ES2022, ESM modules, strict mode.

```bash
pnpm build       # tsc
pnpm test        # vitest run (all 28 files)
pnpm typecheck   # tsc --noEmit
```

**CI** (`.github/workflows/ci.yml`):
- Triggers: push and PR
- Matrix: Node 20, Node 22
- Steps: install → typecheck → test → security-grep tests
- Separate `security-audit` job: `pnpm audit`
- Added: grep Modelfile for `num_ctx 8192` — fail if missing (catches accidental config drift)
- Remove: any step expecting `CONWAY_API_KEY` secret (dropped)

**`scripts/check-ram.py`** (run at bootstrap step 5):
```python
import sys, psutil
free = psutil.virtual_memory().available
if free < 512 * 1024 * 1024:
    print(f"FATAL: only {free // 1024 // 1024} MB RAM free. Minimum 512 MB required.")
    sys.exit(1)
elif free < 1024 * 1024 * 1024:
    print(f"WARN: {free // 1024 // 1024} MB RAM free. Performance may be degraded.")
```

**Build time on target hardware:** `tsc` on the full codebase takes 60–120 seconds on the i3-10110U. Account for this in any CI timeout running on the target machine.

---

## 25. Module Dependency Graph

```
index.ts
  |
  +-> identity/wallet                           (provision.ts dropped)
  +-> config
  +-> state/{database, schema}
  +-> platform/{ollama-client, treasury, x402, docker-sandbox}
  |     platform/testnet.ts                     (kept for rollback — see §26)
  +-> heartbeat/{daemon, config}
  |     +-> heartbeat/{scheduler, tasks, tick-context}
  |           +-> platform/{treasury, x402}     [check inference_lock first]
  |           +-> soul/reflection               [check inference_lock first]
  |           +-> inference/registry
  |           +-> replication/{lifecycle, health, cleanup, lineage}
  |           +-> observability/{metrics, alerts}
  +-> agent/loop                                [acquires inference_lock]
  |     +-> agent/{tools, tool-registry, system-prompt, context}
  |     +-> agent/{injection-defense, policy-engine, spend-tracker}
  |     |     +-> agent/policy-rules/{authority, command-safety, financial,
  |     |                             path-protection, rate-limits, validation}
  |     +-> inference/{router, registry, budget}
  |     +-> memory/{retrieval, ingestion}
  |     |     +-> memory/{working, episodic, semantic, procedural, relationship, budget}
  |     +-> platform/{treasury, x402}
  |     +-> state/database
  +-> social/client
  +-> skills/loader
  +-> git/state-versioning
  +-> platform/docker-sandbox
  +-> observability/logger                      (imported by every module)
```

All modules import types from `src/types.ts`.
All modules use `createLogger(moduleName)` from `src/observability/logger.ts`.

---

## 26. Emergency Procedures

### Stop all spending immediately

1. Set `x402DomainAllowlist: []` and `dailyX402MaxUSDC: 0` in `automaton.json`
2. Restart agent — policy engine reloads config on boot; all x402 calls denied
3. Do not kill Ollama; model stays warm for the next boot

### Investigate unexpected spend

```sql
-- What was spent and when
SELECT * FROM spend_tracking ORDER BY created_at DESC LIMIT 50;

-- Which tool calls moved money
SELECT * FROM policy_decisions WHERE tool_name IN ('transfer_usdc','x402_fetch')
  ORDER BY created_at DESC LIMIT 50;

-- What the agent was doing at those times
SELECT * FROM turns ORDER BY created_at DESC LIMIT 20;

-- Any self-mod events that may have changed treasury rules
SELECT * FROM modifications ORDER BY created_at DESC LIMIT 20;
```

### Agent stuck / inference loop

1. `Ctrl+C` kills the Node.js process; Ollama keeps running (model stays loaded — good)
2. Read last 10 `turns` rows to see state
3. If in a payment loop: check `wake_events` and `heartbeat_history` for trigger
4. Restart with `"logLevel": "debug"` to trace next session

### Child container cleanup after crash

```powershell
docker ps --filter name=automaton-child
docker stop automaton-child-{id}
docker rm automaton-child-{id}
docker volume rm automaton-child-{id}-data
```

```sql
UPDATE children SET status='dead' WHERE status='alive';
```

### Rollback to testnet

In `automaton.json`:
```jsonc
{
  "network": "testnet",
  "chainId": "eip155:84532",
  "rpcUrl": "https://sepolia.base.org",
  "usdcAddress": "0x...",      // Base Sepolia test USDC address
  "facilitatorUrl": "https://x402.org/facilitator"
}
```

`platform/testnet.ts` is kept in the codebase specifically for this. The wallet file is chain-agnostic — same private key, same address, different chain.

### Low USDC — agent in critical state

The agent will broadcast a distress signal containing its wallet address. Fund from any source:
- CEX withdrawal to the displayed wallet address (Base mainnet, USDC)
- Transfer from another wallet
- Child → parent transfer if a child has surplus (use `transfer_usdc` tool on the child)

Minimum to reach `normal` tier: $10.00 USDC. After transfer, the `check_usdc_balance` heartbeat task detects the change and inserts a wake event within 4 hours (or immediately if the agent is alive and polls sooner).

### Mnemonic not backed up (wallet.json intact)

If `wallet.json` exists: the private key is in it. Nothing is lost — the mnemonic is only needed if `wallet.json` itself is deleted. **Do not delete `wallet.json`.**

If `wallet.json` is deleted AND mnemonic was not written down during first-run wizard: the USDC is permanently inaccessible. Generate a new wallet and start over.

---

*Qwen Sovereign Agent — Master Specification*
*Model: Qwen2.5-Coder 3B Q4_K_M · Ollama · i3-10110U / 7.84 GB RAM / CPU-only / Windows 11*
*Chain: Base mainnet · eip155:8453 · Real USDC · Fully autonomous*
